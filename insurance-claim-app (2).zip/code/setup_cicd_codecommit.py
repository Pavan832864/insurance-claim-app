"""
AWS CodePipeline + CodeBuild Setup for Elastic Beanstalk with CodeCommit
Creates CI/CD pipeline that builds and deploys to Elastic Beanstalk from CodeCommit
"""
import boto3
import json
import sys
import time

# AWS Clients
codepipeline = boto3.client('codepipeline', region_name='eu-north-1')
codebuild = boto3.client('codebuild', region_name='eu-north-1')
codecommit = boto3.client('codecommit', region_name='eu-north-1')
iam = boto3.client('iam')
s3_client = boto3.client('s3', region_name='eu-north-1')
eb = boto3.client('elasticbeanstalk', region_name='eu-north-1')

# Configuration
AWS_ACCOUNT_ID = boto3.client('sts').get_caller_identity()['Account']
AWS_REGION = 'eu-north-1'
PROJECT_NAME = 'InsuranceClaimApp'
APP_NAME = 'insurance-claim-app'
ENV_NAME = 'insurance-claim-app-single'
REPO_NAME = 'insurance-claim-app'
ARTIFACT_BUCKET = f'{APP_NAME}-pipeline-artifacts-{AWS_ACCOUNT_ID}'

print("="*80)
print("AWS CodePipeline + CodeBuild Setup for Elastic Beanstalk (CodeCommit)")
print("="*80)

# Step 1: Create CodeCommit Repository
print("\n[1/8] Creating CodeCommit repository...")
try:
    response = codecommit.create_repository(
        repositoryName=REPO_NAME,
        repositoryDescription='Insurance Claim Management System'
    )
    repo_url = response['repositoryMetadata']['cloneUrlHttp']
    print(f"✓ CodeCommit repository created: {REPO_NAME}")
    print(f"  Clone URL: {repo_url}")
except codecommit.exceptions.RepositoryNameExistsException:
    response = codecommit.get_repository(repositoryName=REPO_NAME)
    repo_url = response['repositoryMetadata']['cloneUrlHttp']
    print(f"✓ CodeCommit repository already exists: {REPO_NAME}")
    print(f"  Clone URL: {repo_url}")
except Exception as e:
    print(f"✗ Error creating repository: {str(e)}")
    sys.exit(1)

# Step 2: Create S3 bucket for artifacts
print("\n[2/8] Creating S3 artifact bucket...")
try:
    s3_client.create_bucket(
        Bucket=ARTIFACT_BUCKET,
        CreateBucketConfiguration={'LocationConstraint': AWS_REGION}
    )
    s3_client.put_bucket_versioning(
        Bucket=ARTIFACT_BUCKET,
        VersioningConfiguration={'Status': 'Enabled'}
    )
    print(f"✓ Artifact bucket created: {ARTIFACT_BUCKET}")
except s3_client.exceptions.BucketAlreadyOwnedByYou:
    print(f"✓ Artifact bucket already exists: {ARTIFACT_BUCKET}")
except Exception as e:
    print(f"✗ Error creating artifact bucket: {str(e)}")
    sys.exit(1)

# Step 3: Create IAM Roles
print("\n[3/8] Creating IAM roles...")

# CodePipeline Service Role
pipeline_role_name = 'CodePipelineServiceRole-InsuranceClaim'
pipeline_role_policy = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {"Service": "codepipeline.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }
    ]
}

pipeline_role_arn = None
try:
    response = iam.create_role(
        RoleName=pipeline_role_name,
        AssumeRolePolicyDocument=json.dumps(pipeline_role_policy),
        Description='Service role for CodePipeline'
    )
    pipeline_role_arn = response['Role']['Arn']
    print(f"✓ CodePipeline service role created: {pipeline_role_name}")
except iam.exceptions.EntityAlreadyExistsException:
    pipeline_role_arn = f'arn:aws:iam::{AWS_ACCOUNT_ID}:role/{pipeline_role_name}'
    print(f"✓ CodePipeline service role already exists: {pipeline_role_name}")

# Attach policies to CodePipeline role
pipeline_policies = [
    'arn:aws:iam::aws:policy/AWSCodePipeline_FullAccess',
    'arn:aws:iam::aws:policy/AmazonS3FullAccess',
    'arn:aws:iam::aws:policy/CloudWatchLogsFullAccess',
    'arn:aws:iam::aws:policy/AWSCodeCommitFullAccess'
]

for policy_arn in pipeline_policies:
    try:
        iam.attach_role_policy(RoleName=pipeline_role_name, PolicyArn=policy_arn)
    except Exception as e:
        print(f"  Note: Policy attachment: {str(e)}")

# CodeBuild Service Role
codebuild_role_name = 'CodeBuildServiceRole-InsuranceClaim'
codebuild_role_policy = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {"Service": "codebuild.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }
    ]
}

codebuild_role_arn = None
try:
    response = iam.create_role(
        RoleName=codebuild_role_name,
        AssumeRolePolicyDocument=json.dumps(codebuild_role_policy),
        Description='Service role for CodeBuild'
    )
    codebuild_role_arn = response['Role']['Arn']
    print(f"✓ CodeBuild service role created: {codebuild_role_name}")
    time.sleep(2)  # Wait for role to propagate
except iam.exceptions.EntityAlreadyExistsException:
    codebuild_role_arn = f'arn:aws:iam::{AWS_ACCOUNT_ID}:role/{codebuild_role_name}'
    print(f"✓ CodeBuild service role already exists: {codebuild_role_name}")
    
    # Verify trust policy is correct
    try:
        current_policy = iam.get_role(RoleName=codebuild_role_name)['Role']['AssumeRolePolicyDocument']
        if 'codebuild.amazonaws.com' not in str(current_policy):
            print(f"  ⚠ Updating trust policy...")
            iam.update_assume_role_policy(
                RoleName=codebuild_role_name,
                PolicyDocument=json.dumps(codebuild_role_policy)
            )
            time.sleep(2)
            print(f"  ✓ Trust policy updated")
    except Exception as e:
        print(f"  ⚠ Could not verify trust policy: {str(e)}")

# CodeBuild inline policy
codebuild_policy = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents",
                "s3:GetObject",
                "s3:PutObject",
                "s3:GetObjectVersion",
                "s3:GetBucketVersioning",
                "s3:PutObjectAcl",
                "codebuild:CreateReport",
                "codebuild:UpdateReport",
                "codebuild:BatchPutTestCases",
                "codebuild:BatchPutCodeCoverages",
                "codecommit:GitPush",
                "codecommit:GitPull",
                "codecommit:GetBranch",
                "codecommit:GetCommit",
                "codecommit:GetRepository",
                "codecommit:ListBranches",
                "codecommit:ListRepositories",
                "elasticbeanstalk:*",
                "ec2:*",
                "iam:PassRole"
            ],
            "Resource": "*"
        }
    ]
}

try:
    iam.put_role_policy(
        RoleName=codebuild_role_name,
        PolicyName='CodeBuildPolicy',
        PolicyDocument=json.dumps(codebuild_policy)
    )
    print(f"✓ CodeBuild policy attached")
except Exception as e:
    print(f"  Note: Policy attachment: {str(e)}")

# Step 4: Create CodeBuild Project
print("\n[4/8] Creating CodeBuild project...")

codebuild_config = {
    'name': 'InsuranceClaimAppBuild',
    'description': 'Build project for Insurance Claim Management System',
    'source': {
        'type': 'CODECOMMIT',
        'location': repo_url,
        'buildspec': 'buildspec.yml'
    },
    'artifacts': {
        'type': 'S3',
        'location': ARTIFACT_BUCKET,
        'name': 'build-artifact',
        'packaging': 'ZIP'
    },
    'environment': {
        'type': 'LINUX_CONTAINER',
        'image': 'aws/codebuild/standard:7.0',
        'computeType': 'BUILD_GENERAL1_SMALL',
        'privilegedMode': False,
        'environmentVariables': [
            {'name': 'AWS_REGION', 'value': AWS_REGION},
            {'name': 'APP_NAME', 'value': APP_NAME},
            {'name': 'ENV_NAME', 'value': ENV_NAME}
        ]
    },
    'serviceRole': codebuild_role_arn,
    'timeoutInMinutes': 60
}

try:
    codebuild.create_project(**codebuild_config)
    print("✓ CodeBuild project created: InsuranceClaimAppBuild")
except codebuild.exceptions.ResourceAlreadyExistsException:
    print("✓ CodeBuild project already exists")
    codebuild.update_project(**codebuild_config)
    print("✓ CodeBuild project updated")
except Exception as e:
    print(f"✗ Error creating CodeBuild project: {str(e)}")
    sys.exit(1)

# Step 5: Create CodePipeline
print("\n[5/8] Creating CodePipeline...")

pipeline_config = {
    'name': 'InsuranceClaimAppPipeline',
    'roleArn': pipeline_role_arn,
    'artifactStore': {
        'type': 'S3',
        'location': ARTIFACT_BUCKET
    },
    'stages': [
        {
            'name': 'Source',
            'actions': [
                {
                    'name': 'SourceAction',
                    'actionTypeId': {
                        'category': 'Source',
                        'owner': 'AWS',
                        'provider': 'CodeCommit',
                        'version': '1'
                    },
                    'configuration': {
                        'RepositoryName': REPO_NAME,
                        'BranchName': 'master',
                        'PollForSourceChanges': 'true'
                    },
                    'outputArtifacts': [{'name': 'SourceOutput'}]
                }
            ]
        },
        {
            'name': 'Build',
            'actions': [
                {
                    'name': 'BuildAction',
                    'actionTypeId': {
                        'category': 'Build',
                        'owner': 'AWS',
                        'provider': 'CodeBuild',
                        'version': '1'
                    },
                    'configuration': {
                        'ProjectName': 'InsuranceClaimAppBuild'
                    },
                    'inputArtifacts': [{'name': 'SourceOutput'}],
                    'outputArtifacts': [{'name': 'BuildOutput'}]
                }
            ]
        },
        {
            'name': 'Deploy',
            'actions': [
                {
                    'name': 'DeployAction',
                    'actionTypeId': {
                        'category': 'Deploy',
                        'owner': 'AWS',
                        'provider': 'ElasticBeanstalk',
                        'version': '1'
                    },
                    'configuration': {
                        'ApplicationName': APP_NAME,
                        'EnvironmentName': ENV_NAME
                    },
                    'inputArtifacts': [{'name': 'BuildOutput'}]
                }
            ]
        }
    ]
}

try:
    codepipeline.create_pipeline(**pipeline_config)
    print("✓ CodePipeline created: InsuranceClaimAppPipeline")
except codepipeline.exceptions.PipelineNameInUseException:
    print("✓ CodePipeline already exists")
    codepipeline.update_pipeline(**pipeline_config)
    print("✓ CodePipeline updated")
except Exception as e:
    print(f"✗ Error creating CodePipeline: {str(e)}")
    sys.exit(1)

# Step 6: Summary
print("\n" + "="*80)
print("CI/CD Setup Complete!")
print("="*80)
print(f"\nPipeline Name: InsuranceClaimAppPipeline")
print(f"Build Project: InsuranceClaimAppBuild")
print(f"Artifact Bucket: {ARTIFACT_BUCKET}")
print(f"Deployment Target: {ENV_NAME}")
print(f"\nCodeCommit Repository: {REPO_NAME}")
print(f"Repository URL: {repo_url}")
print("\nNext Steps:")
print("1. Push your code to CodeCommit:")
print(f"   git remote add codecommit {repo_url}")
print("   git push codecommit master")
print("\n2. The pipeline will automatically trigger on push!")
print("\n3. View pipeline:")
print("   https://console.aws.amazon.com/codesuite/codepipeline/pipelines/InsuranceClaimAppPipeline/view")

