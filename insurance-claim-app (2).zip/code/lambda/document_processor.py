"""
AWS Lambda function for processing claim documents
Triggered by S3 events
"""
import json
import boto3
import logging
import os
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
textract_client = boto3.client('textract')

TABLE_NAME = os.getenv('DYNAMODB_TABLE_NAME', 'insurance-claims')

def lambda_handler(event, context):
    """
    Process S3 document upload events
    Extract text from documents and update DynamoDB
    """
    try:
        logger.info(f"Processing document upload event: {json.dumps(event)}")
        
        # Get bucket and key from S3 event
        for record in event['Records']:
            bucket = record['s3']['bucket']['name']
            key = record['s3']['object']['key']
            
            # Extract claim ID from S3 key (format: claims/CLM-XXXXX/filename)
            claim_id = key.split('/')[1] if len(key.split('/')) > 1 else None
            
            if not claim_id:
                logger.warning(f"Could not extract claim ID from key: {key}")
                continue
            
            # Process document with Textract
            document_text = extract_document_text(bucket, key)
            
            # Update claim metadata in DynamoDB
            update_claim_documents(claim_id, key, document_text)
            
            logger.info(f"Document processed for claim: {claim_id}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Documents processed successfully'})
        }
        
    except Exception as e:
        logger.error(f"Error processing documents: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def extract_document_text(bucket, key):
    """Extract text from document using AWS Textract"""
    try:
        # Start async document analysis
        response = textract_client.start_document_text_detection(
            DocumentLocation={
                'S3Object': {
                    'Bucket': bucket,
                    'Name': key
                }
            }
        )
        
        job_id = response['JobId']
        logger.info(f"Started Textract job: {job_id}")
        
        # In production, implement polling or SNS notifications
        # For now, return job ID
        return f"Processing with job ID: {job_id}"
        
    except Exception as e:
        logger.error(f"Error extracting document text: {str(e)}")
        return ""

def update_claim_documents(claim_id, document_key, extracted_text):
    """Update claim document metadata in DynamoDB"""
    try:
        table = dynamodb.Table(TABLE_NAME)
        
        # Update document processing status
        table.update_item(
            Key={'claim_id': claim_id},
            UpdateExpression='SET document_processing_status = :status, processed_at = :timestamp',
            ExpressionAttributeValues={
                ':status': 'Processed',
                ':timestamp': datetime.now().isoformat()
            }
        )
        
        logger.info(f"Updated claim {claim_id} with document metadata")
        
    except Exception as e:
        logger.error(f"Error updating claim documents: {str(e)}")
