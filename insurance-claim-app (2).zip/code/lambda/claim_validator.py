"""
AWS Lambda function for asynchronous claim validation
Triggered by DynamoDB stream events
"""
import json
import boto3
import logging
import os
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource('dynamodb')
sns_client = boto3.client('sns')

TABLE_NAME = os.getenv('DYNAMODB_TABLE_NAME', 'insurance-claims')
SNS_TOPIC_ARN = os.getenv('SNS_TOPIC_ARN')

def lambda_handler(event, context):
    """
    Process DynamoDB stream events for claim validation
    """
    try:
        logger.info(f"Processing {len(event['Records'])} records from DynamoDB stream")
        
        for record in event['Records']:
            if record['eventName'] == 'INSERT':
                claim_data = record['dynamodb']['NewImage']
                
                # Validate claim data
                validation_result = validate_claim(claim_data)
                
                # Send notification if high-risk claim
                if validation_result.get('fraud_risk_level') == 'High':
                    send_alert(claim_data, validation_result)
                    
                logger.info(f"Claim validated: {claim_data.get('claim_id', {}).get('S', 'Unknown')}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Claims validated successfully'})
        }
        
    except Exception as e:
        logger.error(f"Error processing records: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def validate_claim(claim_data):
    """Validate individual claim"""
    fraud_score = 0
    amount = float(claim_data.get('amount', {}).get('N', 0))
    
    # Fraud detection logic
    if amount > 100000:
        fraud_score += 30
    if amount > 50000:
        fraud_score += 20
        
    fraud_level = 'High' if fraud_score > 50 else 'Medium' if fraud_score > 25 else 'Low'
    
    return {
        'fraud_risk_score': fraud_score,
        'fraud_risk_level': fraud_level,
        'is_valid': fraud_score <= 75
    }

def send_alert(claim_data, validation_result):
    """Send SNS alert for high-risk claims"""
    claim_id = claim_data.get('claim_id', {}).get('S', 'Unknown')
    message = f"""
    HIGH-RISK CLAIM ALERT
    
    Claim ID: {claim_id}
    Amount: ${claim_data.get('amount', {}).get('N', 'Unknown')}
    Fraud Risk Score: {validation_result.get('fraud_risk_score')}
    
    This claim requires immediate review.
    """
    
    sns_client.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject='High-Risk Claim Alert',
        Message=message
    )
