"""
AWS Lambda function for sending notifications
Triggered by SNS or CloudWatch events
"""
import json
import boto3
import logging
import os
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

ses_client = boto3.client('ses')
sns_client = boto3.client('sns')

def lambda_handler(event, context):
    """
    Send notifications for claim status changes
    """
    try:
        logger.info(f"Processing notification event: {json.dumps(event)}")
        
        # Parse SNS message if present
        if 'Records' in event:
            for record in event['Records']:
                if record.get('EventSource') == 'aws:sns':
                    message = json.loads(record['Sns']['Message'])
                    send_notification(message)
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Notification sent successfully'})
        }
        
    except Exception as e:
        logger.error(f"Error sending notification: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def send_notification(data):
    """Send email or SMS notification"""
    try:
        email = data.get('email')
        claim_id = data.get('claim_id')
        status = data.get('status')
        
        subject = f"Insurance Claim Update - {claim_id}"
        body = f"""
        Your insurance claim has been updated.
        
        Claim ID: {claim_id}
        Status: {status}
        Updated: {datetime.now().isoformat()}
        
        Please log in to your dashboard to view details.
        """
        
        # Send via SES
        if email:
            ses_client.send_email(
                Source='noreply@insuranceclaims.com',
                Destination={'ToAddresses': [email]},
                Message={
                    'Subject': {'Data': subject},
                    'Body': {'Text': {'Data': body}}
                }
            )
            logger.info(f"Email sent to {email}")
        
    except Exception as e:
        logger.error(f"Error sending notification: {str(e)}")
