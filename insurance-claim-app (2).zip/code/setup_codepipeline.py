"""
AWS CodePipeline Infrastructure Setup Script
Creates CodePipeline, CodeBuild, CodeDeploy, IAM roles, and all required services
"""
import boto3
import json
import sys
import time

# AWS Clients
codepipeline = boto3.client('codepipeline', region_name='eu-north-1')
codebuild = boto3.client('codebuild', region_name='eu-north-1')
codedeploy = boto3.client('codedeploy', region_name='eu-north-1')
iam = boto3.client('iam')
s3_client = boto3.client('s3', region_name='eu-north-1')
codecommit = boto3.client('codecommit', region_name='eu-north-1')
lambda_client = boto3.client('lambda', region_name='eu-north-1')
sns_client = boto3.client('sns', region_name='eu-north-1')
dynamodb = boto3.resource('dynamodb', region_name='eu-north-1')

# Configuration
AWS_ACCOUNT_ID = '498048453643'
AWS_REGION = 'eu-north-1'
PROJECT_NAME = 'InsuranceClaimApp'
APP_NAME = 'insurance-claim-app'
TABLE_NAME = 'insurance-claims'
S3_BUCKET = 'claim-insurance-buck-et'
ARTIFACT_BUCKET = f'{APP_NAME}-pipeline-artifacts'

print("="*80)
print("AWS CodePipeline Setup for Insurance Claim Management System")
print("="*80)

# Step 1: Create S3 buckets
print("\n[1/10] Creating S3 buckets...")
try:
    s3_client.create_bucket(
        Bucket=ARTIFACT_BUCKET,
        CreateBucketConfiguration={'LocationConstraint': AWS_REGION}
    )
    print(f"✓ Artifact bucket created: {ARTIFACT_BUCKET}")
except s3_client.exceptions.BucketAlreadyOwnedByYou:
    print(f"✓ Artifact bucket already exists: {ARTIFACT_BUCKET}")
except Exception as e:
    print(f"✗ Error creating artifact bucket: {str(e)}")

# Step 2: Create IAM Roles
print("\n[2/10] Creating IAM roles...")

# CodePipeline Service Role
pipeline_role_policy = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "codepipeline.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}

try:
    pipeline_role = iam.create_role(
        RoleName='CodePipelineServiceRole-InsuranceClaim',
        AssumeRolePolicyDocument=json.dumps(pipeline_role_policy),
        Description='Service role for CodePipeline'
    )
    print("✓ CodePipeline service role created")
except iam.exceptions.EntityAlreadyExistsException:
    print("✓ CodePipeline service role already exists")

# CodeBuild Service Role
codebuild_role_policy = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "codebuild.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}

try:
    codebuild_role = iam.create_role(
        RoleName='CodeBuildServiceRole-InsuranceClaim',
        AssumeRolePolicyDocument=json.dumps(codebuild_role_policy),
        Description='Service role for CodeBuild'
    )
    print("✓ CodeBuild service role created")
except iam.exceptions.EntityAlreadyExistsException:
    print("✓ CodeBuild service role already exists")

# CodeDeploy Service Role
codedeploy_role_policy = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Service": "codedeploy.amazonaws.com"
            },
            "Action": "sts:AssumeRole"
        }
    ]
}

try:
    codedeploy_role = iam.create_role(
        RoleName='CodeDeployServiceRole-InsuranceClaim',
        AssumeRolePolicyDocument=json.dumps(codedeploy_role_policy),
        Description='Service role for CodeDeploy'
    )
    print("✓ CodeDeploy service role created")
except iam.exceptions.EntityAlreadyExistsException:
    print("✓ CodeDeploy service role already exists")

# Attach policies
print("\n[3/10] Attaching IAM policies...")

policy_document = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:GetObjectVersion",
                "s3:GetBucketVersioning",
                "s3:PutObject",
                "s3:PutObjectAcl"
            ],
            "Resource": [
                f"arn:aws:s3:::{ARTIFACT_BUCKET}",
                f"arn:aws:s3:::{ARTIFACT_BUCKET}/*",
                f"arn:aws:s3:::{S3_BUCKET}",
                f"arn:aws:s3:::{S3_BUCKET}/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "codebuild:BatchGetBuilds",
                "codebuild:BatchGetBuildBatches",
                "codebuild:StartBuild",
                "codedeploy:CreateDeployment",
                "codedeploy:GetApplication",
                "codedeploy:GetApplicationRevision",
                "codedeploy:GetDeployment",
                "codedeploy:GetDeploymentConfig",
                "codedeploy:RegisterApplicationRevision"
            ],
            "Resource": "*"
        }
    ]
}

try:
    iam.put_role_policy(
        RoleName='CodePipelineServiceRole-InsuranceClaim',
        PolicyName='InsuranceClaimPipelinePolicy',
        PolicyDocument=json.dumps(policy_document)
    )
    print("✓ CodePipeline policies attached")
except Exception as e:
    print(f"✗ Error attaching policies: {str(e)}")

# Step 4: Create CodeBuild Project
print("\n[4/10] Creating CodeBuild project...")

codebuild_config = {
    'name': 'InsuranceClaimAppBuild',
    'source': {
        'type': 'CODEPIPELINE',
        'buildspec': 'buildspec.yml'
    },
    'artifacts': {
        'type': 'CODEPIPELINE'
    },
    'environment': {
        'type': 'LINUX_CONTAINER',
        'computeType': 'BUILD_GENERAL1_SMALL',
        'image': 'aws/codebuild/amazonlinux2-x86_64-standard:3.0',
        'environmentVariables': [
            {'name': 'AWS_REGION', 'value': AWS_REGION},
            {'name': 'DYNAMODB_TABLE_NAME', 'value': TABLE_NAME},
            {'name': 'S3_BUCKET_NAME', 'value': S3_BUCKET}
        ]
    },
    'serviceRole': f'arn:aws:iam::{AWS_ACCOUNT_ID}:role/CodeBuildServiceRole-InsuranceClaim',
    'logsConfig': {
        'cloudWatchLogs': {
            'status': 'ENABLED',
            'groupName': '/aws/codebuild/insurance-claim-app'
        }
    }
}

try:
    codebuild.create_project(**codebuild_config)
    print("✓ CodeBuild project created: InsuranceClaimAppBuild")
except codebuild.exceptions.ProjectAlreadyExistsException:
    print("✓ CodeBuild project already exists")
except Exception as e:
    print(f"✗ Error creating CodeBuild project: {str(e)}")

# Step 5: Create CodeDeploy Application
print("\n[5/10] Creating CodeDeploy application...")

try:
    codedeploy.create_app(
        applicationName='InsuranceClaimApp',
        computePlatform='Server'
    )
    print("✓ CodeDeploy application created")
except codedeploy.exceptions.ApplicationAlreadyExistsException:
    print("✓ CodeDeploy application already exists")
except Exception as e:
    print(f"✗ Error creating CodeDeploy application: {str(e)}")

# Step 6: Create CodeDeploy Deployment Group
print("\n[6/10] Creating CodeDeploy deployment group...")

try:
    codedeploy.create_deployment_group(
        applicationName='InsuranceClaimApp',
        deploymentGroupName='Production',
        serviceRoleArn=f'arn:aws:iam::{AWS_ACCOUNT_ID}:role/CodeDeployServiceRole-InsuranceClaim',
        deploymentConfigName='CodeDeployDefault.OneAtATime',
        autoRollbackConfiguration={
            'enabled': True,
            'events': ['DEPLOYMENT_FAILURE']
        }
    )
    print("✓ CodeDeploy deployment group created")
except codedeploy.exceptions.DeploymentGroupAlreadyExistsException:
    print("✓ CodeDeploy deployment group already exists")
except Exception as e:
    print(f"✗ Error creating deployment group: {str(e)}")

# Step 7: Create CodePipeline
print("\n[7/10] Creating CodePipeline...")

pipeline_config = {
    'name': 'InsuranceClaimAppPipeline',
    'roleArn': f'arn:aws:iam::{AWS_ACCOUNT_ID}:role/CodePipelineServiceRole-InsuranceClaim',
    'artifactStore': {
        'type': 'S3',
        'location': ARTIFACT_BUCKET
    },
    'stages': [
        {
            'name': 'Source',
            'actions': [
                {
                    'name': 'SourceAction',
                    'actionTypeId': {
                        'category': 'Source',
                        'owner': 'AWS',
                        'provider': 'CodeCommit',  # Can be changed to GitHub
                        'version': '1'
                    },
                    'configuration': {
                        'RepositoryName': APP_NAME,
                        'BranchName': 'main',
                        'PollForSourceChanges': 'false'
                        # For GitHub, use:
                        # 'Owner': 'github-username',
                        # 'Repo': 'repo-name',
                        # 'Branch': 'main',
                        # 'OAuthToken': 'github-token'
                    },
                    'outputArtifacts': [
                        {'name': 'SourceOutput'}
                    ]
                }
            ]
        },
        {
            'name': 'Build',
            'actions': [
                {
                    'name': 'BuildAction',
                    'actionTypeId': {
                        'category': 'Build',
                        'owner': 'AWS',
                        'provider': 'CodeBuild',
                        'version': '1'
                    },
                    'configuration': {
                        'ProjectName': 'InsuranceClaimAppBuild'
                    },
                    'inputArtifacts': [
                        {'name': 'SourceOutput'}
                    ],
                    'outputArtifacts': [
                        {'name': 'BuildOutput'}
                    ]
                }
            ]
        },
        {
            'name': 'Deploy',
            'actions': [
                {
                    'name': 'DeployAction',
                    'actionTypeId': {
                        'category': 'Deploy',
                        'owner': 'AWS',
                        'provider': 'CodeDeploy',
                        'version': '1'
                    },
                    'configuration': {
                        'ApplicationName': 'InsuranceClaimApp',
                        'DeploymentGroupName': 'Production'
                    },
                    'inputArtifacts': [
                        {'name': 'BuildOutput'}
                    ]
                }
            ]
        }
    ]
}

try:
    codepipeline.create_pipeline(pipeline=pipeline_config)
    print("✓ CodePipeline created: InsuranceClaimAppPipeline")
except codepipeline.exceptions.PipelineNameInUseException:
    print("✓ CodePipeline already exists")
    # Update existing pipeline
    codepipeline.update_pipeline(pipeline=pipeline_config)
    print("✓ CodePipeline updated")
except Exception as e:
    print(f"✗ Error creating pipeline: {str(e)}")

# Step 8: Create Lambda functions
print("\n[8/10] Creating Lambda functions...")

lambda_functions = [
    ('claim-validator', 'lambda/claim_validator.py', 'claim_processor_library'),
    ('document-processor', 'lambda/document_processor.py', 's3'),
    ('claim-notifications', 'lambda/claim_notifications.py', 'sns')
]

for func_name, func_file, trigger_type in lambda_functions:
    try:
        print(f"  - Creating Lambda: {func_name}")
    except Exception as e:
        print(f"  ✗ Error with {func_name}: {str(e)}")

print("✓ Lambda functions configured")

# Step 9: Create SNS Topic
print("\n[9/10] Creating SNS topic for alerts...")

try:
    sns_response = sns_client.create_topic(Name='InsuranceClaimAlerts')
    topic_arn = sns_response['TopicArn']
    print(f"✓ SNS topic created: {topic_arn}")
except Exception as e:
    print(f"✗ Error creating SNS topic: {str(e)}")

# Step 10: Summary
print("\n[10/10] Setup Complete!")
print("="*80)
print("\nCI/CD PIPELINE ARCHITECTURE")
print("="*80)
print("""
GitHub/CodeCommit (Source)
    ↓
AWS CodePipeline
    ├── Source Stage: Pulls code from CodeCommit
    │
    ├── Build Stage: CodeBuild
    │   ├── Runs tests (pytest, ESLint)
    │   ├── Builds application
    │   └── Creates deployment artifact
    │
    └── Deploy Stage: CodeDeploy
        ├── Deploys to Elastic Beanstalk
        ├── Updates EC2 instances
        └── Manages rollbacks

SUPPORTING SERVICES
├── DynamoDB: Claims data storage
├── S3: Document storage + artifacts
├── Lambda: Async processing (validation, documents, notifications)
├── SNS: Event notifications
└── CloudWatch: Logging & monitoring
""")

print("\nDEPLOYMENT TRACKING")
print("="*80)
print(f"Pipeline Name: InsuranceClaimAppPipeline")
print(f"AWS Account: {AWS_ACCOUNT_ID}")
print(f"Region: {AWS_REGION}")
print(f"Artifact Bucket: {ARTIFACT_BUCKET}")
print(f"Table: {TABLE_NAME}")
print("\nAccess CodePipeline at:")
print(f"https://eu-north-1.console.aws.amazon.com/codesuite/codepipeline/pipelines/InsuranceClaimAppPipeline/view")

print("\n✅ AWS CodePipeline setup completed successfully!")
