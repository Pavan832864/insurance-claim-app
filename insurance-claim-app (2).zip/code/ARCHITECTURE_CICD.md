# Insurance Claim Management System - Complete CI/CD Architecture

## Executive Summary

This application implements a **complete DevOps/CI-CD pipeline** using AWS services that automates the entire software delivery process from code commit to production deployment.

**Architecture Flow:**
\`\`\`
Developer Push → CodeCommit → CodePipeline → CodeBuild → CodeDeploy → Elastic Beanstalk
                                ↓              ↓           ↓
                           Source Stage   Build & Test   Deploy & Rollback
\`\`\`

---

## Technology Stack

### Core Application
- **Frontend**: Next.js + React (HTML, CSS, JavaScript)
- **Backend**: Flask (Python)
- **Database**: AWS DynamoDB (NoSQL)
- **Storage**: AWS S3 (documents)

### CI/CD Infrastructure
1. **AWS CodePipeline** - Orchestration service
2. **AWS CodeBuild** - Testing & building service
3. **AWS CodeDeploy** - Deployment automation
4. **AWS Elastic Beanstalk** - Managed application hosting
5. **AWS DynamoDB** - Database storage
6. **AWS S3** - Artifact & document storage
7. **AWS Lambda** - Serverless computing (3 functions)
8. **AWS SNS** - Event notifications
9. **AWS CloudWatch** - Logging & monitoring
10. **AWS IAM** - Access control & security

**Total: 10 AWS Services**

---

## CI/CD Pipeline Stages

### Stage 1: Source
**Service**: AWS CodeCommit (Git repository)

\`\`\`yaml
Trigger: Push to 'main' branch
Action: Fetch latest code
Output: Source artifact (repository snapshot)
\`\`\`

**Developer Workflow:**
\`\`\`bash
git add .
git commit -m "Feature: Add claim validation"
git push origin main  # ← Triggers pipeline
\`\`\`

### Stage 2: Build
**Service**: AWS CodeBuild

**Execution Flow:**
\`\`\`
1. Install Dependencies
   ├── Python (Flask, boto3, pytest)
   ├── Node.js (Next.js, React)
   └── System packages (git, build tools)

2. Test & Quality Checks
   ├── Run pytest (Python unit tests)
   ├── Run flake8 (Python linting)
   ├── Run ESLint (JavaScript linting)
   └── Generate coverage reports

3. Build Application
   ├── Build Next.js frontend
   ├── Compile Python backend
   └── Package dependencies

4. Create Artifact
   ├── ZIP all files
   ├── Include Dockerfile
   ├── Include appspec.yml
   └── Upload to S3
\`\`\`

**Configuration**: `buildspec.yml`
- Defines build phases (pre_build, build, post_build)
- Specifies artifacts to upload
- Sets environment variables
- Configures caching

### Stage 3: Deploy
**Service**: AWS CodeDeploy

**Deployment Flow:**
\`\`\`
1. Download artifact from S3
2. Stop current application
   └── Kill Flask & Next.js processes
3. Install new version
   ├── Update Python dependencies
   ├── Update Node modules
   └── Update system packages
4. Start application
   ├── Start Gunicorn (Flask)
   ├── Start Next.js
   └── Health checks
5. Monitor deployment
   ├── Verify endpoints respond
   ├── Check error rates
   └── Auto-rollback if failed
\`\`\`

**Configuration**: `appspec.yml`
- Defines lifecycle hooks
- Specifies which scripts to run
- Sets file permissions
- Configures health checks

---

## Detailed Component Architecture

\`\`\`
┌─────────────────────────────────────────────────────────────────┐
│                     AWS CODEPIPELINE                            │
│  Orchestrates the entire CI/CD workflow across all services     │
└──────────────┬──────────────────────┬────────────────────────────┘
               │                      │
       ┌───────▼────────┐     ┌──────▼──────────┐
       │  CODECOMMIT    │     │   CODEBUILD    │
       │  (Source)      │     │  (Build/Test)  │
       │                │     │                │
       │ ┌─────────┐    │     │ ┌────────────┐ │
       │ │ app.py  │    │     │ │buildspec.yml
       │ │ app.tsx │    │     │ │            │ │
       │ │ config  │    │     │ │ pytest     │ │
       │ └─────────┘    │     │ │ flake8     │ │
       │                │     │ │ ESLint     │ │
       └────────────────┘     │ │ Build pkg  │ │
                              │ └────────────┘ │
                              └────────┬───────┘
                                       │ artifacts
                                       ▼
                                   ┌─────────────┐
                                   │  S3 BUCKET  │
                              ┌────┤  Artifacts  │
                              │    │             │
                              │    └─────────────┘
                              │
                    ┌─────────▼──────────────┐
                    │   CODEDEPLOY         │
                    │  (Deploy/Rollback)   │
                    │                      │
                    │ ┌──────────────────┐ │
                    │ │ appspec.yml      │ │
                    │ │ deployment hooks │ │
                    │ │ health checks    │ │
                    │ └──────────────────┘ │
                    └─────────┬────────────┘
                              │
                    ┌─────────▼──────────────────┐
                    │  ELASTIC BEANSTALK        │
                    │  (Application Host)       │
                    │                           │
                    │ ┌─────────────────────┐  │
                    │ │ EC2 Instances       │  │
                    │ │ ├─ Flask (port 5000)│  │
                    │ │ └─ Next.js (port 80)│  │
                    │ └─────────────────────┘  │
                    │ ┌─────────────────────┐  │
                    │ │ Load Balancer       │  │
                    │ │ Health Checks       │  │
                    │ └─────────────────────┘  │
                    └────────┬─────────────────┘
                             │
            ┌────────────────┼────────────────┐
            │                │                │
   ┌────────▼────┐  ┌────────▼─────┐  ┌──────▼──────┐
   │ DYNAMODB    │  │  S3 BUCKET   │  │  CLOUDWATCH │
   │             │  │  Documents   │  │   Logs      │
   │ Claims      │  │              │  │             │
   │ Storage     │  │ ├─ PDFs      │  │ ├─ Build    │
   │             │  │ ├─ Images    │  │ ├─ Deploy   │
   │ TTL: 365d   │  │ └─ Docs      │  │ └─ App      │
   └─────────────┘  └──────────────┘  └─────────────┘

SERVERLESS PROCESSING
┌──────────────────────────────────────────────────────────┐
│ AWS LAMBDA (3 Functions)                                 │
│                                                          │
│ ┌──────────────────┐  ┌──────────────────┐ ┌──────────┐ │
│ │Claim Validator   │  │Document Processor│ │Notifier  │ │
│ │                  │  │                  │ │          │ │
│ │Trigger: DynamoDB │  │Trigger: S3 Event │ │Trigger:  │ │
│ │Stream            │  │                  │ │SNS Topic │ │
│ │                  │  │Extracts text     │ │          │ │
│ │Fraud scoring     │  │with AWS Textract │ │Sends     │ │
│ │Risk assessment   │  │Updates DynamoDB  │ │emails    │ │
│ │Send SNS alert    │  │                  │ │          │ │
│ └──────────────────┘  └──────────────────┘ └──────────┘ │
│         │                    │                   │       │
│         └────────┬───────────┴───────────────────┘       │
│                  │                                       │
│              SNS Topic (Notifications)                   │
└──────────────────────────────────────────────────────────┘
\`\`\`

---

## Pipeline Execution Timeline

\`\`\`
Time 0:00    Developer pushes code
   ↓
   ├─→ Source Stage (0.5 min)
   │   ├─ CodeCommit pulls repository
   │   └─ Creates source artifact
   │
   ├─→ Build Stage (3-5 min) ← Main bottleneck
   │   ├─ Install dependencies
   │   ├─ Run tests
   │   ├─ Lint code
   │   ├─ Build application
   │   └─ Upload artifact to S3
   │
   └─→ Deploy Stage (2-3 min)
       ├─ Download artifact
       ├─ Stop application
       ├─ Install new version
       ├─ Start application
       └─ Health checks

TOTAL TIME: ~6-9 minutes from push to live
\`\`\`

---

## Data Flow

### Creating an Insurance Claim

\`\`\`
1. User submits form (Frontend → Flask API)
   ↓
2. Flask validates input
   ↓
3. Data stored in DynamoDB
   ↓
4. Documents uploaded to S3
   ↓
5. DynamoDB stream triggers Lambda (Claim Validator)
   ↓
6. Lambda scores fraud risk
   ↓
7. If high-risk → SNS alert → Notification Lambda → Email user
   ↓
8. Dashboard updates via CloudWatch metrics
\`\`\`

### Deployment Pipeline

\`\`\`
1. Developer commits code
   ↓
2. CodeCommit webhook triggers CodePipeline
   ↓
3. CodeBuild runs tests on buildspec.yml
   ↓
4. If tests pass → Package created
   ↓
5. CodeDeploy pulls from S3 with appspec.yml
   ↓
6. Runs deployment scripts (before_install.sh, start_app.sh)
   ↓
7. Elastic Beanstalk health checks
   ↓
8. If healthy → LIVE
   ↓
9. If failed → AUTO-ROLLBACK
\`\`\`

---

## Key Files

### CI/CD Configuration Files
- `buildspec.yml` - CodeBuild execution instructions
- `appspec.yml` - CodeDeploy execution instructions
- `setup_codepipeline.py` - Automated infrastructure setup
- `aws-codepipeline-config.json` - Pipeline configuration

### Deployment Scripts
- `scripts/before_install.sh` - Dependencies installation
- `scripts/start_app.sh` - Start Flask & Next.js
- `scripts/stop_app.sh` - Stop running applications

### Lambda Functions
- `lambda/claim_validator.py` - Fraud detection
- `lambda/document_processor.py` - Document extraction
- `lambda/claim_notifications.py` - User notifications

---

## Security Architecture

### IAM Roles & Policies
\`\`\`
CodePipeline Role
├── S3 access (read/write artifacts)
├── CodeBuild permission (trigger builds)
└── CodeDeploy permission (trigger deployments)

CodeBuild Role
├── S3 access (download source, upload artifacts)
├── ECR access (container images)
├── CloudWatch (write logs)
└── DynamoDB (run tests)

CodeDeploy Role
├── S3 access (download artifacts)
├── EC2 access (deploy to instances)
├── Elastic Beanstalk access
└── CloudWatch (write logs)
\`\`\`

### Data Security
- **DynamoDB**: Encryption at rest + in transit
- **S3**: Server-side encryption (SSE-S3)
- **Credentials**: AWS IAM roles (no hardcoded keys)
- **Network**: VPC isolation for EC2 instances

---

## Monitoring & Observability

### CloudWatch Dashboards
\`\`\`
Real-time Metrics:
├── Pipeline success rate
├── Build duration
├── Deployment frequency
├── Application errors
└── Database performance
\`\`\`

### Log Groups
\`\`\`
/aws/codepipeline/insurance-claim-app
/aws/codebuild/insurance-claim-app
/aws/elasticbeanstalk/insurance-claim-app
/aws/lambda/claim-validator
/aws/lambda/document-processor
/aws/lambda/claim-notifications
\`\`\`

### Alarms & Notifications
\`\`\`
SNS Topic: InsuranceClaimAlerts
├── Pipeline failures
├── High-risk claims
├── Deployment issues
└── Lambda errors
\`\`\`

---

## Deployment Strategies

### Blue-Green Deployment
\`\`\`
Blue (Current)     Green (New)
└─ Version 1      └─ Version 2
        │              │
        └──EB Swap──────┘
             ↓
        Instant Rollback
\`\`\`

### Canary Deployment
\`\`\`
Send 10% traffic → New version
Monitor 5 minutes
If OK: Send 100% traffic
If Failed: Rollback
\`\`\`

### Rolling Deployment
\`\`\`
Instance 1: Stop → Update → Start
Instance 2: Stop → Update → Start
Instance 3: Stop → Update → Start
(Maintains availability)
\`\`\`

---

## Scalability

### Horizontal Scaling
\`\`\`
CodePipeline: Handles unlimited concurrent pipelines
CodeBuild: Auto-scales build capacity (1-100 concurrent builds)
Lambda: Auto-scales to thousands of concurrent executions
DynamoDB: On-demand pricing scales automatically
\`\`\`

### Vertical Scaling
\`\`\`
EC2 instances: t3.micro → t3.small → t3.medium
Build instances: BUILD_GENERAL1_SMALL → LARGE → 2XLARGE
\`\`\`

---

## Cost Breakdown (Monthly Estimates)

\`\`\`
AWS CodePipeline:     $1.00 (flat rate)
AWS CodeBuild:        ~$20 (50 minutes/day @ $0.005/min)
AWS CodeDeploy:       $0 (free tier)
AWS Lambda:           ~$5 (serverless processing)
AWS DynamoDB:         ~$30 (on-demand)
AWS S3:               ~$2 (storage + requests)
AWS Elastic Beanstalk: ~$50 (t3.micro EC2)
AWS CloudWatch:       ~$3 (logs + metrics)
───────────────────────────────
Total Monthly:        ~$110 - $150

Free tier eligible: First year savings ~$100/month
\`\`\`

---

## Success Criteria

✅ **Fully Automated**: No manual deployments
✅ **Fast Feedback**: Tests run in <10 minutes
✅ **Reliable**: Auto-rollback on failures
✅ **Scalable**: Handles growth without changes
✅ **Secure**: IAM roles, encryption, VPC isolation
✅ **Observable**: Comprehensive logging & monitoring
✅ **Cost-Effective**: Auto-scaling infrastructure

---

## Next Steps

1. Run `python3 setup_codepipeline.py` to create infrastructure
2. Push code to CodeCommit to trigger pipeline
3. Monitor execution in CodePipeline console
4. Configure alerts in CloudWatch
5. Setup on-call escalation via SNS

Your application is now production-ready with enterprise-grade CI/CD!
