const API_BASE_URL = "/api"

// UI State
let currentRole = null // null = landing page, "customer" or "admin"
let customerEmail = null // Store customer email
let allClaims = []
let currentFilter = ""
let adminLoggedIn = false

// Initialize - Start with landing page
document.addEventListener("DOMContentLoaded", () => {
  setupEventListeners()
  showLandingPage()
})

function setupEventListeners() {
  // Landing page buttons
  document.getElementById("btnCustomerPortal").addEventListener("click", () => showCustomerEmailModal())
  document.getElementById("btnAdminPortal").addEventListener("click", () => showAdminLoginModal())
  
  // Customer email modal
  document.getElementById("customerEmailForm").addEventListener("submit", handleCustomerEmailSubmit)
  document.getElementById("closeCustomerEmailModal").addEventListener("click", closeCustomerEmailModal)
  document.getElementById("customerEmailModal").addEventListener("click", (e) => {
    if (e.target.id === "customerEmailModal") closeCustomerEmailModal()
  })
  
  // Admin login modal
  document.getElementById("adminLoginForm").addEventListener("submit", handleAdminLogin)
  document.getElementById("closeLoginModal").addEventListener("click", closeAdminLoginModal)
  document.getElementById("adminLoginModal").addEventListener("click", (e) => {
    if (e.target.id === "adminLoginModal") closeAdminLoginModal()
  })
  
  // Navigation (only visible after portal selection)
  const navCustomer = document.getElementById("navCustomer")
  const navAdmin = document.getElementById("navAdmin")
  const navLogout = document.getElementById("navLogout")
  
  if (navCustomer) {
    navCustomer.addEventListener("click", () => {
      if (customerEmail) {
        switchToCustomerPortal()
      } else {
        showCustomerEmailModal()
      }
    })
  }
  
  if (navAdmin) {
    navAdmin.addEventListener("click", () => {
      if (adminLoggedIn) {
        switchToAdminDashboard()
      } else {
        showAdminLoginModal()
      }
    })
  }
  
  if (navLogout) {
    navLogout.addEventListener("click", handleAdminLogout)
  }

  // Customer section
  document.getElementById("claimForm").addEventListener("submit", handleClaimSubmit)

  // Admin section
  document.getElementById("statusFilter").addEventListener("change", (e) => {
    currentFilter = e.target.value
    loadAdminClaims()
  })
  document.getElementById("refreshBtn").addEventListener("click", loadAdminClaims)

  // Modal
  const modalClose = document.querySelector(".modal-close")
  if (modalClose) {
    modalClose.addEventListener("click", closeModal)
  }
  document.getElementById("claimModal").addEventListener("click", (e) => {
    if (e.target.id === "claimModal") closeModal()
  })

  // File upload
  const fileUpload = document.querySelector(".file-upload")
  const fileInput = document.getElementById("documents")
  if (fileUpload && fileInput) {
    fileUpload.addEventListener("click", () => fileInput.click())
    fileInput.addEventListener("change", (e) => {
      const count = e.target.files.length
      if (count > 0) {
        document.querySelector(".file-hint").textContent = `${count} file(s) selected`
      }
    })
  }
}

// Landing Page Functions
function showLandingPage() {
  currentRole = null
  // Hide all sections except landing
  document.getElementById("landingSection").classList.add("active")
  document.getElementById("customerSection").classList.remove("active")
  document.getElementById("adminSection").classList.remove("active")
  document.getElementById("mainNavbar").style.display = "none"
}

// Customer Email Entry
function showCustomerEmailModal() {
  document.getElementById("customerEmailModal").classList.add("active")
  document.getElementById("customerEmail").focus()
  document.getElementById("customerEmailError").style.display = "none"
}

function closeCustomerEmailModal() {
  document.getElementById("customerEmailModal").classList.remove("active")
  document.getElementById("customerEmailForm").reset()
  document.getElementById("customerEmailError").style.display = "none"
}

async function handleCustomerEmailSubmit(e) {
  e.preventDefault()
  
  const email = document.getElementById("customerEmail").value.trim()
  const errorDiv = document.getElementById("customerEmailError")
  
  // Clear previous errors
  errorDiv.style.display = "none"
  errorDiv.textContent = ""
  
  // Validate email
  if (!email) {
    errorDiv.textContent = "Please enter your email address"
    errorDiv.style.display = "block"
    return
  }
  
  if (!email.includes("@") || !email.includes(".")) {
    errorDiv.textContent = "Please enter a valid email address"
    errorDiv.style.display = "block"
    return
  }
  
  // Store customer email and proceed to customer portal
  customerEmail = email
  closeCustomerEmailModal()
  switchToCustomerPortal()
}

function switchToCustomerPortal() {
  if (!customerEmail) {
    showCustomerEmailModal()
    return
  }
  
  currentRole = "customer"
  
  // Hide landing page, show customer portal
  document.getElementById("landingSection").classList.remove("active")
  document.getElementById("customerSection").classList.add("active")
  document.getElementById("adminSection").classList.remove("active")
  document.getElementById("mainNavbar").style.display = "flex"
  
  // Update navbar
  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.classList.remove("active")
    if (btn.id === "navCustomer") {
      btn.classList.add("active")
    }
    if (btn.id === "navLogout") {
      btn.style.display = "none"
    }
  })
  
  // Pre-fill email in form
  document.getElementById("email").value = customerEmail
  
  // Load customer claims
  loadCustomerClaims()
}

// Admin Login Functions
function showAdminLoginModal() {
  document.getElementById("adminLoginModal").classList.add("active")
  document.getElementById("adminEmail").focus()
  document.getElementById("loginError").style.display = "none"
}

function closeAdminLoginModal() {
  document.getElementById("adminLoginModal").classList.remove("active")
  document.getElementById("adminLoginForm").reset()
  document.getElementById("loginError").style.display = "none"
}

async function handleAdminLogin(e) {
  e.preventDefault()
  
  const email = document.getElementById("adminEmail").value.trim()
  const password = document.getElementById("adminPassword").value
  const errorDiv = document.getElementById("loginError")
  
  // Clear previous errors
  errorDiv.style.display = "none"
  errorDiv.textContent = ""
  
  // Validate input
  if (!email || !password) {
    errorDiv.textContent = "Please enter both email and password"
    errorDiv.style.display = "block"
    return
  }
  
  try {
    const response = await fetch(`${API_BASE_URL}/admin/login`, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      credentials: 'include',
      body: JSON.stringify({ email, password })
    })
    
    // Check if response is OK
    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`HTTP error! status: ${response.status}, body: ${errorText}`)
    }
    
    const data = await response.json()
    
    if (data.success) {
      adminLoggedIn = true
      closeAdminLoginModal()
      showToast("Login successful! Redirecting to admin dashboard...", "success")
      // Automatically switch to admin dashboard after successful login
      setTimeout(() => {
        switchToAdminDashboard()
      }, 500)
    } else {
      errorDiv.textContent = data.error || "Invalid email or password"
      errorDiv.style.display = "block"
    }
  } catch (error) {
    console.error("Login error:", error)
    errorDiv.textContent = `Failed to login: ${error.message}. Please check your connection and try again.`
    errorDiv.style.display = "block"
  }
}

function switchToAdminDashboard() {
  if (!adminLoggedIn) {
    showAdminLoginModal()
    return
  }
  
  currentRole = "admin"
  
  // Hide landing page, show admin dashboard
  document.getElementById("landingSection").classList.remove("active")
  document.getElementById("customerSection").classList.remove("active")
  document.getElementById("adminSection").classList.add("active")
  document.getElementById("mainNavbar").style.display = "flex"
  
  // Update navbar
  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.classList.remove("active")
    if (btn.id === "navAdmin") {
      btn.classList.add("active")
    }
    if (btn.id === "navLogout") {
      btn.style.display = "block"
    }
  })
  
  // Load admin data
  loadAdminClaims()
  loadStats()
}

async function handleAdminLogout() {
  try {
    const response = await fetch(`${API_BASE_URL}/admin/logout`, {
      method: "POST",
      credentials: 'include'
    })
    
    const data = await response.json()
    
    if (data.success) {
      adminLoggedIn = false
      showToast("Logged out successfully", "success")
    } else {
      adminLoggedIn = false
    }
  } catch (error) {
    console.error("Logout error:", error)
    adminLoggedIn = false
  }
  
  // Return to landing page
  showLandingPage()
}

// Claim Functions
async function handleClaimSubmit(e) {
  e.preventDefault()

  const formData = new FormData(document.getElementById("claimForm"))
  
  // Ensure email is set
  if (!formData.get("email")) {
    formData.set("email", customerEmail)
  }

  try {
    const response = await fetch(`${API_BASE_URL}/claims`, {
      method: "POST",
      body: formData,
    })

    const data = await response.json()

    if (data.success) {
      showToast(`Claim ${data.claim_id} submitted successfully!`, "success")
      document.getElementById("claimForm").reset()
      // Re-set email
      document.getElementById("email").value = customerEmail
      document.querySelector(".file-hint").textContent = "Upload PDFs, images, or documents (max 10MB each)"
      setTimeout(() => loadCustomerClaims(), 1000)
    } else {
      showToast(data.errors ? data.errors.join(", ") : "Error submitting claim", "error")
    }
  } catch (error) {
    console.error("Error:", error)
    showToast("Failed to submit claim", "error")
  }
}

async function loadCustomerClaims() {
  if (!customerEmail) {
    document.getElementById("customerClaimsList").innerHTML = '<p class="loading">Enter your email to view claims</p>'
    return
  }

  try {
    const response = await fetch(`${API_BASE_URL}/claims?email=${encodeURIComponent(customerEmail)}&role=customer`)
    const data = await response.json()

    const container = document.getElementById("customerClaimsList")

    if (!data.success || data.claims.length === 0) {
      container.innerHTML = '<p class="loading">No claims found for this email</p>'
      return
    }

    allClaims = data.claims
    container.innerHTML = data.claims
      .map(
        (claim) => `
            <div class="claim-card" onclick="viewClaimDetails('${claim.claim_id}')">
                <div class="claim-card-header">
                    <span class="claim-id">${claim.claim_id}</span>
                    <span class="status-badge status-${claim.status.toLowerCase()}">${claim.status}</span>
                </div>
                <div class="claim-info">
                    <div class="claim-info-item">
                        <span class="claim-info-label">Type:</span> ${claim.claim_type}
                    </div>
                    <div class="claim-info-item">
                        <span class="claim-info-label">Amount:</span> $${Number(claim.amount).toLocaleString()}
                    </div>
                    <div class="claim-info-item">
                        <span class="claim-info-label">Date:</span> ${new Date(claim.incident_date).toLocaleDateString()}
                    </div>
                    <div class="claim-info-item">
                        <span class="claim-info-label">Submitted:</span> ${new Date(claim.created_at).toLocaleDateString()}
                    </div>
                </div>
            </div>
        `,
      )
      .join("")
  } catch (error) {
    console.error("Error:", error)
    showToast("Failed to load claims", "error")
  }
}

async function loadAdminClaims() {
  try {
    let url = `${API_BASE_URL}/claims?role=admin`
    if (currentFilter) {
      url += `&status=${encodeURIComponent(currentFilter)}`
    }

    const response = await fetch(url, {
      credentials: 'include'
    })
    const data = await response.json()
    
    if (!data.success && data.error && data.error.includes("authentication")) {
      adminLoggedIn = false
      showToast("Session expired. Please login again.", "error")
      showAdminLoginModal()
      return
    }

    const container = document.getElementById("adminClaimsList")

    if (!data.success || data.claims.length === 0) {
      container.innerHTML = '<p class="loading">No claims found</p>'
      return
    }

    const table = document.createElement("table")
    table.className = "admin-table"
    table.innerHTML = `
            <thead>
                <tr>
                    <th>Claim ID</th>
                    <th>Customer</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Risk Level</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                ${data.claims
                  .map(
                    (claim) => `
                    <tr>
                        <td><strong>${claim.claim_id}</strong></td>
                        <td>${claim.customer_name}</td>
                        <td>${claim.claim_type}</td>
                        <td>$${Number(claim.amount).toLocaleString()}</td>
                        <td><span class="status-badge status-${claim.status.toLowerCase()}">${claim.status}</span></td>
                        <td><span class="risk-${claim.fraud_risk_level.toLowerCase()}">${claim.fraud_risk_level}</span></td>
                        <td><button class="btn btn-secondary" onclick="viewClaimDetails('${claim.claim_id}')">Review</button></td>
                    </tr>
                `,
                  )
                  .join("")}
            </tbody>
        `

    container.innerHTML = ""
    container.appendChild(table)
  } catch (error) {
    console.error("Error:", error)
    showToast("Failed to load admin claims", "error")
  }
}

async function loadStats() {
  try {
    const response = await fetch(`${API_BASE_URL}/stats`, {
      credentials: 'include'
    })
    const data = await response.json()
    
    if (!data.success && data.error && data.error.includes("authentication")) {
      adminLoggedIn = false
      showToast("Session expired. Please login again.", "error")
      showAdminLoginModal()
      return
    }

    if (data.success) {
      const stats = data.stats
      document.getElementById("statTotal").textContent = stats.total_claims
      document.getElementById("statPending").textContent = stats.pending
      document.getElementById("statApproved").textContent = stats.approved
      document.getElementById("statRisk").textContent = stats.high_risk_count
    }
  } catch (error) {
    console.error("Error loading stats:", error)
  }
}

async function viewClaimDetails(claimId) {
  try {
    const response = await fetch(`${API_BASE_URL}/claims/${claimId}`)
    const data = await response.json()

    if (!data.success) {
      showToast("Failed to load claim details", "error")
      return
    }

    const claim = data.claim
    const modalBody = document.getElementById("modalBody")

    let actionButtons = ""
    if (currentRole === "admin" && adminLoggedIn) {
      actionButtons = `
                <div style="margin-top: 1.5rem; display: flex; gap: 1rem;">
                    <button class="btn btn-success" onclick="updateClaimStatus('${claimId}', 'Approved')">Approve</button>
                    <button class="btn btn-danger" onclick="updateClaimStatus('${claimId}', 'Rejected')">Reject</button>
                    <button class="btn btn-primary" onclick="updateClaimStatus('${claimId}', 'Settled')">Settle</button>
                </div>
            `
    }

    modalBody.innerHTML = `
            <h3>${claim.claim_id}</h3>
            <div style="margin-top: 1rem; line-height: 1.8;">
                <p><strong>Customer:</strong> ${claim.customer_name}</p>
                <p><strong>Email:</strong> ${claim.email}</p>
                <p><strong>Policy Number:</strong> ${claim.policy_number}</p>
                <p><strong>Claim Type:</strong> ${claim.claim_type}</p>
                <p><strong>Amount:</strong> $${Number(claim.amount).toLocaleString()}</p>
                <p><strong>Incident Date:</strong> ${new Date(claim.incident_date).toLocaleDateString()}</p>
                <p><strong>Status:</strong> <span class="status-badge status-${claim.status.toLowerCase()}">${claim.status}</span></p>
                <p><strong>Fraud Risk:</strong> <span class="risk-${claim.fraud_risk_level?.toLowerCase() || "low"}">${claim.fraud_risk_level || "Low"}</span></p>
                <p><strong>Priority:</strong> ${claim.priority_level || "Normal"}</p>
                <hr style="margin: 1rem 0; border: none; border-top: 1px solid #e2e8f0;">
                <p><strong>Description:</strong></p>
                <p style="background: #f1f5f9; padding: 1rem; border-radius: 0.5rem; margin-top: 0.5rem;">${claim.description}</p>
                ${
                  claim.documents && claim.documents.length > 0
                    ? `
                    <p style="margin-top: 1rem;"><strong>Documents (${claim.documents.length}):</strong></p>
                    <ul style="margin-top: 0.5rem; padding-left: 1.5rem;">
                        ${claim.documents.map((doc) => `<li>${doc.filename}</li>`).join("")}
                    </ul>
                `
                    : ""
                }
                ${actionButtons}
            </div>
        `

    document.getElementById("claimModal").classList.add("active")
  } catch (error) {
    console.error("Error:", error)
    showToast("Failed to load claim details", "error")
  }
}

async function updateClaimStatus(claimId, newStatus) {
  const adminNotes = prompt("Enter admin notes (optional):")

  try {
    const response = await fetch(`${API_BASE_URL}/claims/${claimId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      credentials: 'include',
      body: JSON.stringify({
        status: newStatus,
        admin_notes: adminNotes || "",
      }),
    })
    
    const data = await response.json()
    
    if (!data.success && data.error && data.error.includes("authentication")) {
      adminLoggedIn = false
      showToast("Session expired. Please login again.", "error")
      showAdminLoginModal()
      return
    }

    if (data.success) {
      showToast(`Claim status updated to ${newStatus}`, "success")
      closeModal()
      loadAdminClaims()
      loadStats()
    } else {
      showToast("Failed to update claim", "error")
    }
  } catch (error) {
    console.error("Error:", error)
    showToast("Failed to update claim", "error")
  }
}

function closeModal() {
  document.getElementById("claimModal").classList.remove("active")
  document.getElementById("modalBody").innerHTML = ""
}

function showToast(message, type = "info") {
  const toast = document.getElementById("toast")
  toast.textContent = message
  toast.className = `toast show ${type}`
  setTimeout(() => {
    toast.classList.remove("show")
  }, 4000)
}
