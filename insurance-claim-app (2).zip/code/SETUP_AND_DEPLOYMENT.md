# Insurance Claims Management System - Setup & Deployment Guide

Complete guide for setting up and deploying the Insurance Claims Management System on AWS.

## 📋 Table of Contents

1. [Initial Setup (New Machine)](#initial-setup-new-machine)
2. [Deployment Methods](#deployment-methods)
3. [Making Changes & Deploying](#making-changes--deploying)
4. [Troubleshooting](#troubleshooting)

---

## 🚀 Initial Setup (New Machine)

### Prerequisites

- Python 3.11+
- AWS CLI installed and configured
- AWS Account with credentials
- Elastic Beanstalk CLI (`eb`)

### Step 1: Install Dependencies


# Install Python dependencies
pip3.11 install -r requirements.txt

# Install Elastic Beanstalk CLI (if not installed)
pip3.11 install awsebcli
```

### Step 2: Configure AWS CLI

```bash
aws configure
# Enter your AWS Access Key ID
# Enter your AWS Secret Access Key
# Default region: eu-north-1
# Default output format: json
```

### Step 3: Initialize Elastic Beanstalk (if needed)

```bash
eb init insurance-claim-app --region eu-north-1 --platform "Python 3.11"
```

### Step 4: Verify AWS Resources

The following AWS resources should already exist (created during initial setup):

- **DynamoDB Table**: `insurance-claims`
- **S3 Bucket**: `claim-insurance-buck-et`
- **Elastic Beanstalk Application**: `insurance-claim-app`
- **Elastic Beanstalk Environment**: `insurance-claim-app-single`
- **IAM Roles**: Various roles for EB, CodePipeline, etc.

### Step 5: Set Environment Variables (if needed)

```bash
eb setenv \
  AWS_REGION=eu-north-1 \
  S3_BUCKET_NAME=claim-insurance-buck-et \
  DYNAMODB_TABLE_NAME=insurance-claims \
  SECRET_KEY=your-secret-key-change-in-production
```

---

## 📦 Deployment Methods

You have **two deployment options** depending on your needs:

### Option 1: Direct Deployment (Recommended - Bypasses CodeBuild)

**Script:** `./deploy_automated.sh`

**When to use:**
- ✅ CodeBuild has account limits (0 concurrent builds)
- ✅ Quick deployments
- ✅ Bypasses CI/CD pipeline
- ✅ Most reliable method
- ✅ **Use this for regular deployments**

**How it works:**
1. Creates zip package with your code
2. Uploads to S3
3. Creates Elastic Beanstalk application version
4. Deploys directly to environment
5. Cleans up local files

**Usage:**
```bash
./deploy_automated.sh
```

### Option 2: CodePipeline Deployment (When CodeBuild is Available)

**Script:** `./deploy.sh`

**When to use:**
- ✅ CodeBuild limit has been increased (request from AWS Support)
- ✅ Want full CI/CD pipeline with build/testing stages
- ✅ Need automated testing and validation

**How it works:**
1. Creates zip package
2. Uploads to S3 pipeline bucket (`insurance-claim-app-pipeline-artifacts-498048453643/source.zip`)
3. Triggers CodePipeline (`InsuranceClaimAppPipeline`)
4. CodeBuild runs (if limit increased)
5. Deploys to Elastic Beanstalk

**Usage:**
```bash
./deploy.sh
```

**Note:** This will fail if CodeBuild limit is 0. Use `./deploy_automated.sh` instead until limit is increased.

---

## 🔄 Making Changes & Deploying

### Workflow

1. **Make your code changes** in:
   - `app.py` (backend)
   - `static/index.html` (frontend)
   - `static/app.js` (frontend JavaScript)
   - `static/styles.css` (styling)
   - `.ebextensions/*.config` (EB configuration)

2. **Deploy using one of the methods:**

   **Quick deployment (recommended):**
   ```bash
   ./deploy_automated.sh
   ```

   **Or via CodePipeline (if CodeBuild available):**
   ```bash
   ./deploy.sh
   ```

3. **Monitor deployment:**
   ```bash
   eb status insurance-claim-app-single
   ```

4. **Check logs:**
   ```bash
   eb logs insurance-claim-app-single
   ```

### Important Notes

- **No Git Required**: These deployment scripts work without git commits
- **Manual S3 Deployment**: Both scripts create zip files and upload to S3
- **CodeBuild Limits**: If `deploy.sh` fails, use `deploy_automated.sh` instead

---

## 🔍 Troubleshooting

### Deployment Fails

**Check environment status:**
```bash
eb status insurance-claim-app-single
```

**View recent logs:**
```bash
eb logs insurance-claim-app-single --all
```

**Check CloudWatch Logs:**
- Go to AWS Console → CloudWatch → Log Groups
- Look for `/aws/elasticbeanstalk/insurance-claim-app/web`

### CodeBuild Fails

**Error:** `AccountLimitExceededException: Cannot have more than 0 builds in queue`

**Solution:** Use `./deploy_automated.sh` instead, or request CodeBuild limit increase from AWS Support.

### Logs Not Appearing in CloudWatch

**Check:**
1. CloudWatch Agent is running (configured in `.ebextensions/04_cloudwatch.config`)
2. IAM role has CloudWatch permissions (already configured)
3. Log groups exist: `/aws/elasticbeanstalk/insurance-claim-app/web`

**Verify:**
```bash
aws logs describe-log-groups --region eu-north-1 \
  --log-group-name-prefix "/aws/elasticbeanstalk/insurance-claim-app"
```

### Admin Authentication Not Working

**Credentials:**
- Email: `admin@gmail.com`
- Password: `admin12`

**Check:**
1. Routes are registered (check `eb logs` for route registration)
2. Session cookies are enabled (CORS configured)
3. Admin routes are at the top of `app.py`

---

## 📊 Application URL

**Production URL:**
```
http://insurance-claim-app-single.eba-neqfphnn.eu-north-1.elasticbeanstalk.com
```

---

## 🔐 Admin Access

- **Email:** `admin@gmail.com`
- **Password:** `admin12`

---

## 📝 Key Files

- `app.py` - Flask backend application
- `static/index.html` - Frontend HTML
- `static/app.js` - Frontend JavaScript
- `static/styles.css` - Styling
- `.ebextensions/` - Elastic Beanstalk configuration
- `requirements.txt` - Python dependencies
- `deploy_automated.sh` - Direct deployment script
- `deploy.sh` - CodePipeline deployment script

---

## 🆘 Quick Commands Reference

```bash
# Deploy (direct)
./deploy_automated.sh

# Deploy (via CodePipeline - requires CodeBuild)
./deploy.sh

# Check status
eb status insurance-claim-app-single

# View logs
eb logs insurance-claim-app-single

# Check pipeline status
aws codepipeline get-pipeline-state --name InsuranceClaimAppPipeline --region eu-north-1

# View in console
# Elastic Beanstalk: https://console.aws.amazon.com/elasticbeanstalk
# CodePipeline: https://console.aws.amazon.com/codesuite/codepipeline
# CloudWatch: https://console.aws.amazon.com/cloudwatch
```

---

## ✅ Checklist

- [x] Python 3.11+ installed
- [x] AWS CLI configured
- [x] Elastic Beanstalk CLI installed
- [x] Dependencies installed (`pip install -r requirements.txt`)
- [x] AWS resources exist (DynamoDB, S3, EB environment)
- [x] Deployment scripts are executable (`chmod +x deploy*.sh`)
- [x] Code changes tested locally
- [x] Deployment successful

---

**Last Updated:** November 2025  
**Environment:** `insurance-claim-app-single`  
**Region:** `eu-north-1`

