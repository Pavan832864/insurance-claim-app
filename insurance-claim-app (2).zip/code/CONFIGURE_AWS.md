# Configure AWS Credentials

## ✅ Prerequisites Installed

- ✅ Python 3.11.14 installed at `/opt/homebrew/bin/python3.11`
- ✅ AWS CLI 2.31.31 installed

## 🔐 Configure AWS Credentials

You need to configure AWS CLI with your credentials. You have two options:

### Option 1: Interactive Configuration (Recommended)

Run this command and follow the prompts:

```bash
aws configure
```

**You'll be asked for:**
1. **AWS Access Key ID**: `[Enter your access key]`
2. **AWS Secret Access Key**: `[Enter your secret key]`
3. **Default region name**: `eu-north-1` (or your preferred region)
4. **Default output format**: `json`

### Option 2: Manual Configuration

If you prefer to set credentials manually:

```bash
# Create AWS credentials directory
mkdir -p ~/.aws

# Edit credentials file
nano ~/.aws/credentials
```

Add this content:
```ini
[default]
aws_access_key_id = YOUR_ACCESS_KEY_ID
aws_secret_access_key = YOUR_SECRET_ACCESS_KEY
```

Then edit config file:
```bash
nano ~/.aws/config
```

Add this content:
```ini
[default]
region = eu-north-1
output = json
```

## 📋 How to Get AWS Credentials

If you don't have AWS credentials yet:

1. **Log in to AWS Console**: https://console.aws.amazon.com
2. **Go to IAM**: Click on your username → "Security credentials"
3. **Create Access Key**:
   - Click "Create access key"
   - Choose "Command Line Interface (CLI)"
   - Download or copy the Access Key ID and Secret Access Key
   - ⚠️ **Important**: Save the secret key immediately - you can't view it again!

## ✅ Verify Configuration

After configuring, verify it works:

```bash
aws sts get-caller-identity
```

This should return your AWS account ID and user ARN.

## 🚀 Next Steps

Once AWS is configured, you can proceed with:

1. Run `python3.11 aws_complete_setup.py` to set up AWS infrastructure
2. Deploy to Elastic Beanstalk
3. Set up CI/CD pipeline

---

**Current Status:**
- ✅ Python 3.11 installed
- ✅ AWS CLI installed
- ⏳ **Waiting for AWS credentials configuration**

