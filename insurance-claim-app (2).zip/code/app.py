"""
Flask Backend for Insurance Claim Management System
Integrates with AWS DynamoDB, S3, and CloudWatch
"""

from flask import Flask, request, jsonify, session
from flask_cors import CORS
from werkzeug.utils import secure_filename
import boto3
import os
import uuid
from datetime import datetime
from decimal import Decimal
from dotenv import load_dotenv
import logging
from functools import wraps
# Import claim processor library (with error handling to ensure routes register)
try:
    from claim_processor_library import ClaimProcessor, ClaimValidator
except ImportError as e:
    # If import fails, create dummy classes to allow app to start
    # This ensures routes still register even if library is missing
    import sys
    print(f"WARNING: Could not import claim_processor_library: {str(e)}", file=sys.stderr, flush=True)
    class ClaimProcessor:
        @staticmethod
        def validate_and_score_claim(data):
            return {
                'is_valid': True,
                'errors': [],
                'warnings': [],
                'fraud_analysis': {'fraud_risk_score': 0.0, 'risk_level': 'Low'},
                'priority_analysis': {'priority_score': 0.0, 'priority_level': 'Low'}
            }
    class ClaimValidator:
        pass

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__, static_folder='static', static_url_path='/static')
app.secret_key = os.getenv('SECRET_KEY', 'your-secret-key-change-in-production')
CORS(app, supports_credentials=True)

# Configure logging to CloudWatch
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()  # Also log to stdout for CloudWatch
    ]
)
logger = logging.getLogger(__name__)

# AWS Configuration (needed before CloudWatch handler)
AWS_REGION = os.getenv('AWS_REGION', 'eu-north-1')

# Create CloudWatch logger handler
# Note: Elastic Beanstalk automatically captures stdout/stderr logs
# We'll use both watchtower (for direct CloudWatch) and stdout (for EB capture)
try:
    import watchtower
    # Create log group if it doesn't exist
    try:
        logs_client = boto3.client('logs', region_name=AWS_REGION)
        logs_client.create_log_group(logGroupName='/aws/elasticbeanstalk/insurance-claim-app/application')
        logger.info("Created CloudWatch log group: /aws/elasticbeanstalk/insurance-claim-app/application")
    except logs_client.exceptions.ResourceAlreadyExistsException:
        logger.info("CloudWatch log group already exists")
    except Exception as e:
        logger.warning(f"Could not create log group: {str(e)}")
    
    # Get instance ID for stream name
    import requests
    try:
        instance_id = requests.get('http://169.254.169.254/latest/meta-data/instance-id', timeout=2).text
    except:
        instance_id = 'unknown'
    
    cloudwatch_handler = watchtower.CloudWatchLogHandler(
        log_group='/aws/elasticbeanstalk/insurance-claim-app/application',
        stream_name=instance_id,
        use_queues=True,  # Use queues for better reliability
        send_interval=1  # Send logs every 1 second instead of 5
    )
    cloudwatch_handler.setLevel(logging.INFO)
    logger.addHandler(cloudwatch_handler)
    logger.info("CloudWatch logging handler initialized successfully")
    print("CloudWatch logging handler initialized successfully", flush=True)  # Also print to stdout
except ImportError:
    logger.warning("watchtower not installed, logs will go to stdout/stderr (captured by Elastic Beanstalk)")
    print("WARNING: watchtower not installed, using stdout/stderr only", flush=True)
except Exception as e:
    logger.warning(f"Could not initialize CloudWatch handler: {str(e)}, using stdout/stderr only")
    print(f"WARNING: CloudWatch handler failed: {str(e)}, using stdout/stderr only", flush=True)
DYNAMODB_TABLE_NAME = os.getenv('DYNAMODB_TABLE_NAME', 'insurance-claims')
S3_BUCKET_NAME = os.getenv('S3_BUCKET_NAME', 'claim-insurance-buck-et')

# Initialize AWS services
try:
    dynamodb = boto3.resource('dynamodb', region_name=AWS_REGION)
    s3_client = boto3.client('s3', region_name=AWS_REGION)
    cloudwatch = boto3.client('cloudwatch', region_name=AWS_REGION)
    claims_table = dynamodb.Table(DYNAMODB_TABLE_NAME)
    logger.info("AWS services initialized successfully")
except Exception as e:
    logger.error(f"Error initializing AWS services: {str(e)}")

# Upload configuration
ALLOWED_EXTENSIONS = {'pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB


def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# Admin credentials (in production, store in database or environment variables)
ADMIN_EMAIL = 'admin@gmail.com'
ADMIN_PASSWORD = 'admin12'


def admin_required(f):
    """Decorator to require admin authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin_logged_in'):
            logger.warning("Unauthorized admin access attempt")
            return jsonify({'success': False, 'error': 'Admin authentication required'}), 401
        return f(*args, **kwargs)
    return decorated_function


def generate_claim_id():
    """Generate unique claim ID"""
    return f"CLM-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:8]}"


# ============================================================================
# ADMIN ROUTES - Defined first to ensure proper registration
# ============================================================================

@app.route('/api/admin/login', methods=['POST', 'OPTIONS'])
def admin_login():
    """Admin login endpoint"""
    if request.method == 'OPTIONS':
        response = jsonify({'success': True})
        response.headers.add('Access-Control-Allow-Origin', request.headers.get('Origin', '*'))
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
        response.headers.add('Access-Control-Allow-Methods', 'POST, OPTIONS')
        response.headers.add('Access-Control-Allow-Credentials', 'true')
        return response, 200
    
    logger.info("Admin login route called - method: %s", request.method)
    try:
        # Get JSON data
        if not request.is_json:
            return jsonify({'success': False, 'error': 'Content-Type must be application/json'}), 400
        
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400
            
        email = data.get('email', '').strip()
        password = data.get('password', '')
        
        logger.info(f"Admin login attempt: {email}")
        
        if email == ADMIN_EMAIL and password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            session['admin_email'] = email
            logger.info(f"Admin login successful: {email}")
            response = jsonify({
                'success': True,
                'message': 'Login successful'
            })
            response.headers.add('Access-Control-Allow-Origin', request.headers.get('Origin', '*'))
            response.headers.add('Access-Control-Allow-Credentials', 'true')
            return response, 200
        else:
            logger.warning(f"Admin login failed: {email}")
            return jsonify({
                'success': False,
                'error': 'Invalid email or password'
            }), 401
    
    except Exception as e:
        logger.error(f"Error during admin login: {str(e)}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/admin/logout', methods=['POST'])
def admin_logout():
    """Admin logout endpoint"""
    try:
        email = session.get('admin_email', 'unknown')
        session.clear()
        logger.info(f"Admin logout: {email}")
        return jsonify({
            'success': True,
            'message': 'Logout successful'
        }), 200
    except Exception as e:
        logger.error(f"Error during admin logout: {str(e)}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/admin/check', methods=['GET', 'OPTIONS'])
def admin_check():
    """Check if admin is logged in"""
    if request.method == 'OPTIONS':
        response = jsonify({'success': True})
        response.headers.add('Access-Control-Allow-Origin', request.headers.get('Origin', '*'))
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
        response.headers.add('Access-Control-Allow-Methods', 'GET, OPTIONS')
        response.headers.add('Access-Control-Allow-Credentials', 'true')
        return response, 200
    
    is_logged_in = session.get('admin_logged_in', False)
    logger.info(f"Admin check - logged in: {is_logged_in}")
    response = jsonify({
        'success': True,
        'logged_in': is_logged_in
    })
    response.headers.add('Access-Control-Allow-Origin', request.headers.get('Origin', '*'))
    response.headers.add('Access-Control-Allow-Credentials', 'true')
    return response, 200


# IMPORTANT: /api route must come AFTER /api/admin/* routes to avoid route conflicts
# But we'll define it after all other routes to ensure admin routes register first
@app.route('/api', methods=['GET'])
def api_info():
    """API information endpoint"""
    return jsonify({
        'success': True,
        'message': 'Insurance Claim Management System API',
        'version': '1.0',
        'endpoints': {
            'health': '/health',
            'admin_login': 'POST /api/admin/login',
            'admin_logout': 'POST /api/admin/logout',
            'admin_check': 'GET /api/admin/check',
            'create_claim': 'POST /api/claims',
            'get_claims': 'GET /api/claims',
            'get_claim': 'GET /api/claims/<claim_id>',
            'update_claim': 'PUT /api/claims/<claim_id>',
            'delete_claim': 'DELETE /api/claims/<claim_id>',
            'upload_documents': 'POST /api/claims/<claim_id>/documents',
            'get_stats': 'GET /api/stats'
        }
    }), 200


@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    try:
        # Check DynamoDB connection
        claims_table.meta.client.describe_table(TableName=DYNAMODB_TABLE_NAME)
        db_status = 'connected'
    except Exception as e:
        logger.error(f"DynamoDB health check failed: {str(e)}")
        db_status = 'disconnected'
    
    health_data = {
        'status': 'healthy' if db_status == 'connected' else 'degraded',
        'timestamp': datetime.now().isoformat(),
        'database': db_status,
        'region': AWS_REGION
    }
    
    logger.debug(f"Health check: {health_data}")
    return jsonify(health_data), 200 if db_status == 'connected' else 503


@app.route('/api/claims', methods=['POST'])
def create_claim():
    """Create a new insurance claim"""
    try:
        logger.info("Received claim submission request")
        
        # Handle both form data and JSON
        if request.is_json:
            data = request.get_json()
            logger.debug(f"Received JSON data: {list(data.keys())}")
        else:
            data = request.form.to_dict()
            logger.debug(f"Received form data: {list(data.keys())}")
        
        # Validate claim data
        logger.info(f"Validating claim data for customer: {data.get('email', 'unknown')}")
        validation_result = ClaimProcessor.validate_and_score_claim(data)
        
        if not validation_result['is_valid']:
            logger.warning(f"Claim validation failed: {validation_result.get('errors', [])}")
            return jsonify({
                'success': False,
                'errors': validation_result['errors'],
                'warnings': validation_result.get('warnings', [])
            }), 400
        
        # Generate claim ID
        claim_id = generate_claim_id()
        
        # Prepare claim document for DynamoDB
        # Convert float values to Decimal for DynamoDB compatibility
        amount_value = Decimal(str(data.get('amount', 0)))
        fraud_score = validation_result.get('fraud_analysis', {}).get('fraud_risk_score')
        priority_score = validation_result.get('priority_analysis', {}).get('priority_score')
        
        claim_document = {
            'claim_id': claim_id,
            'policy_number': data.get('policy_number'),
            'customer_name': data.get('customer_name'),
            'email': data.get('email'),
            'phone': data.get('phone', ''),
            'claim_type': data.get('claim_type'),
            'amount': amount_value,  # Use Decimal instead of float
            'incident_date': data.get('incident_date'),
            'description': data.get('description'),
            'status': 'Pending',
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat(),
            'fraud_risk_score': Decimal(str(fraud_score)) if fraud_score is not None else None,
            'fraud_risk_level': validation_result.get('fraud_analysis', {}).get('risk_level'),
            'priority_score': Decimal(str(priority_score)) if priority_score is not None else None,
            'priority_level': validation_result.get('priority_analysis', {}).get('priority_level'),
            'documents': []
        }
        
        logger.info(f"Creating claim {claim_id} for customer {data.get('email')} with amount ${amount_value}")
        
        # Handle file uploads
        if 'files' in request.files:
            files = request.files.getlist('files')
            for file in files:
                if file and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    file_key = f"claims/{claim_id}/{filename}"
                    
                    # Upload to S3 with encryption
                    s3_client.upload_fileobj(
                        file,
                        S3_BUCKET_NAME,
                        file_key,
                        ExtraArgs={
                            'ContentType': file.content_type,
                            'ServerSideEncryption': 'AES256'
                        }
                    )
                    
                    claim_document['documents'].append({
                        'filename': filename,
                        's3_key': file_key,
                        'upload_time': datetime.now().isoformat()
                    })
                    
                    logger.info(f"File uploaded: {file_key}")
        
        # Store claim in DynamoDB
        claims_table.put_item(Item=claim_document)
        logger.info(f"Claim {claim_id} successfully stored in DynamoDB")
        
        # Send custom metric to CloudWatch
        try:
            cloudwatch.put_metric_data(
                Namespace='InsuranceClaimApp',
                MetricData=[
                    {
                        'MetricName': 'ClaimsCreated',
                        'Value': 1,
                        'Unit': 'Count',
                        'Timestamp': datetime.now()
                    },
                    {
                        'MetricName': 'ClaimAmount',
                        'Value': float(amount_value),
                        'Unit': 'None',
                        'Timestamp': datetime.now()
                    }
                ]
            )
        except Exception as e:
            logger.warning(f"Could not send CloudWatch metric: {str(e)}")
        
        return jsonify({
            'success': True,
            'message': 'Claim submitted successfully',
            'claim_id': claim_id,
            'claim': claim_document
        }), 201
    
    except Exception as e:
        logger.error(f"Error creating claim: {str(e)}", exc_info=True)
        # Send error metric to CloudWatch
        try:
            cloudwatch.put_metric_data(
                Namespace='InsuranceClaimApp',
                MetricData=[{
                    'MetricName': 'ErrorCount',
                    'Value': 1,
                    'Unit': 'Count',
                    'Timestamp': datetime.now()
                }]
            )
        except:
            pass
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/claims', methods=['GET'])
def get_claims():
    """Retrieve all claims (with optional filtering)"""
    try:
        status_filter = request.args.get('status')
        role = request.args.get('role', 'customer')
        customer_email = request.args.get('email')
        
        # Require admin authentication for admin role
        if role == 'admin':
            if not session.get('admin_logged_in'):
                logger.warning("Unauthorized admin access attempt to get_claims")
                return jsonify({'success': False, 'error': 'Admin authentication required'}), 401
        
        logger.info(f"Fetching claims - status: {status_filter}, role: {role}, email: {customer_email}")
        
        # Scan table
        scan_kwargs = {}
        if status_filter:
            scan_kwargs['FilterExpression'] = '#status = :status'
            scan_kwargs['ExpressionAttributeNames'] = {'#status': 'status'}
            scan_kwargs['ExpressionAttributeValues'] = {':status': status_filter}
        
        response = claims_table.scan(**scan_kwargs)
        items = response.get('Items', [])
        
        # Filter by customer email if customer role
        if role == 'customer' and customer_email:
            items = [item for item in items if item.get('email') == customer_email]
        
        # Sort by created_at
        items.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        
        # Convert Decimal to float for JSON serialization
        for item in items:
            if 'amount' in item and isinstance(item['amount'], Decimal):
                item['amount'] = float(item['amount'])
            if 'fraud_risk_score' in item and isinstance(item['fraud_risk_score'], Decimal):
                item['fraud_risk_score'] = float(item['fraud_risk_score'])
            if 'priority_score' in item and isinstance(item['priority_score'], Decimal):
                item['priority_score'] = float(item['priority_score'])
        
        logger.info(f"Retrieved {len(items)} claims")
        
        return jsonify({
            'success': True,
            'count': len(items),
            'claims': items
        }), 200
    
    except Exception as e:
        logger.error(f"Error retrieving claims: {str(e)}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/claims/<claim_id>', methods=['GET'])
def get_claim(claim_id):
    """Retrieve specific claim details"""
    try:
        logger.info(f"Fetching claim {claim_id}")
        response = claims_table.get_item(Key={'claim_id': claim_id})
        
        if 'Item' not in response:
            logger.warning(f"Claim {claim_id} not found")
            return jsonify({'success': False, 'error': 'Claim not found'}), 404
        
        item = response['Item']
        # Convert Decimal to float for JSON serialization
        if 'amount' in item and isinstance(item['amount'], Decimal):
            item['amount'] = float(item['amount'])
        if 'fraud_risk_score' in item and isinstance(item['fraud_risk_score'], Decimal):
            item['fraud_risk_score'] = float(item['fraud_risk_score'])
        if 'priority_score' in item and isinstance(item['priority_score'], Decimal):
            item['priority_score'] = float(item['priority_score'])
        
        logger.info(f"Successfully retrieved claim {claim_id}")
        return jsonify({
            'success': True,
            'claim': item
        }), 200
    
    except Exception as e:
        logger.error(f"Error retrieving claim {claim_id}: {str(e)}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/claims/<claim_id>', methods=['PUT'])
@admin_required
def update_claim(claim_id):
    """Update claim status (admin only)"""
    try:
        data = request.get_json()
        logger.info(f"Updating claim {claim_id} with status: {data.get('status')}")
        
        # Get existing claim
        response = claims_table.get_item(Key={'claim_id': claim_id})
        if 'Item' not in response:
            logger.warning(f"Claim {claim_id} not found for update")
            return jsonify({'success': False, 'error': 'Claim not found'}), 404
        
        # Update allowed fields
        update_expression = "SET #status = :status, updated_at = :updated_at"
        expression_values = {
            ':status': data.get('status'),
            ':updated_at': datetime.now().isoformat()
        }
        
        if 'admin_notes' in data:
            update_expression += ", admin_notes = :notes"
            expression_values[':notes'] = data['admin_notes']
        
        claims_table.update_item(
            Key={'claim_id': claim_id},
            UpdateExpression=update_expression,
            ExpressionAttributeNames={'#status': 'status'},
            ExpressionAttributeValues=expression_values
        )
        
        logger.info(f"Claim {claim_id} successfully updated to status: {data.get('status')}")
        
        return jsonify({
            'success': True,
            'message': 'Claim updated successfully'
        }), 200
    
    except Exception as e:
        logger.error(f"Error updating claim {claim_id}: {str(e)}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/claims/<claim_id>', methods=['DELETE'])
@admin_required
def delete_claim(claim_id):
    """Delete claim (admin only)"""
    try:
        logger.info(f"Deleting claim {claim_id}")
        claims_table.delete_item(Key={'claim_id': claim_id})
        logger.info(f"Claim {claim_id} successfully deleted")
        
        return jsonify({
            'success': True,
            'message': 'Claim deleted successfully'
        }), 200
    
    except Exception as e:
        logger.error(f"Error deleting claim {claim_id}: {str(e)}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/claims/<claim_id>/documents', methods=['POST'])
def upload_documents(claim_id):
    """Upload documents to existing claim"""
    try:
        logger.info(f"Uploading documents for claim {claim_id}")
        
        if 'files' not in request.files:
            logger.warning(f"No files provided for claim {claim_id}")
            return jsonify({'success': False, 'error': 'No files provided'}), 400
        
        files = request.files.getlist('files')
        uploaded_docs = []
        
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_key = f"claims/{claim_id}/{filename}"
                
                logger.info(f"Uploading file {filename} to S3: {file_key}")
                s3_client.upload_fileobj(
                    file,
                    S3_BUCKET_NAME,
                    file_key,
                    ExtraArgs={
                        'ContentType': file.content_type,
                        'ServerSideEncryption': 'AES256'
                    }
                )
                
                uploaded_docs.append({
                    'filename': filename,
                    's3_key': file_key,
                    'upload_time': datetime.now().isoformat()
                })
                logger.info(f"File {filename} uploaded successfully to S3")
        
        # Update claim documents in DynamoDB
        claims_table.update_item(
            Key={'claim_id': claim_id},
            UpdateExpression="SET documents = list_append(documents, :docs), updated_at = :updated",
            ExpressionAttributeValues={
                ':docs': uploaded_docs,
                ':updated': datetime.now().isoformat()
            }
        )
        
        logger.info(f"Successfully uploaded {len(uploaded_docs)} document(s) for claim {claim_id}")
        return jsonify({
            'success': True,
            'message': f'{len(uploaded_docs)} file(s) uploaded successfully',
            'documents': uploaded_docs
        }), 200
    
    except Exception as e:
        logger.error(f"Error uploading documents for claim {claim_id}: {str(e)}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/stats', methods=['GET'])
@admin_required
def get_stats():
    """Get claims statistics for dashboard (admin only)"""
    try:
        logger.info("Fetching claims statistics")
        response = claims_table.scan()
        items = response.get('Items', [])
        
        # Convert Decimal amounts to float for calculation
        def get_amount(item):
            amount = item.get('amount', 0)
            if isinstance(amount, Decimal):
                return float(amount)
            return float(amount) if amount else 0
        
        total_amount = sum([get_amount(c) for c in items])
        
        stats = {
            'total_claims': len(items),
            'pending': len([c for c in items if c.get('status') == 'Pending']),
            'approved': len([c for c in items if c.get('status') == 'Approved']),
            'rejected': len([c for c in items if c.get('status') == 'Rejected']),
            'settled': len([c for c in items if c.get('status') == 'Settled']),
            'total_amount': total_amount,
            'high_risk_count': len([c for c in items if c.get('fraud_risk_level') == 'High']),
            'high_priority_count': len([c for c in items if c.get('priority_level') == 'High'])
        }
        
        logger.info(f"Stats retrieved: {stats['total_claims']} total claims, ${total_amount:,.2f} total amount")
        
        return jsonify({
            'success': True,
            'stats': stats
        }), 200
    
    except Exception as e:
        logger.error(f"Error getting stats: {str(e)}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.before_request
def log_request():
    """Log all incoming requests"""
    # Skip logging for static files to reduce noise
    if not request.path.startswith('/static'):
        logger.info(f"{request.method} {request.path} - IP: {request.remote_addr}")


@app.after_request
def log_response(response):
    """Log all responses"""
    # Skip logging for static files to reduce noise
    if not request.path.startswith('/static'):
        logger.info(f"{request.method} {request.path} - Status: {response.status_code}")
    return response


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    logger.warning(f"404 error: {request.path} not found")
    return jsonify({'success': False, 'error': 'Endpoint not found'}), 404


@app.errorhandler(500)
def server_error(error):
    """Handle 500 errors"""
    logger.error(f"500 error on {request.path}: {str(error)}", exc_info=True)
    # Send error metric
    try:
        cloudwatch.put_metric_data(
            Namespace='InsuranceClaimApp',
            MetricData=[{
                'MetricName': 'ErrorCount',
                'Value': 1,
                'Unit': 'Count',
                'Timestamp': datetime.now()
            }]
        )
    except:
        pass
    return jsonify({'success': False, 'error': 'Internal server error'}), 500


# Root routes - defined last to avoid conflicts with API routes
@app.route('/', methods=['GET'])
def index():
    """Serve the frontend HTML page"""
    return app.send_static_file('index.html')


@app.route('/index.html', methods=['GET'])
def index_html():
    """Serve the frontend HTML page (alternative route)"""
    return app.send_static_file('index.html')


# Log registered routes on startup (for debugging)
def log_registered_routes():
    """Log all registered routes for debugging"""
    logger.info("=" * 60)
    logger.info("REGISTERED ROUTES:")
    admin_routes_found = False
    for rule in app.url_map.iter_rules():
        methods = list(rule.methods - {'HEAD', 'OPTIONS'})
        if 'admin' in rule.rule:
            admin_routes_found = True
            logger.info(f"  ✓ {rule.rule} - {methods}")
        else:
            logger.debug(f"  {rule.rule} - {methods}")
    if not admin_routes_found:
        logger.error("❌ NO ADMIN ROUTES FOUND IN REGISTRATION!")
    logger.info("=" * 60)

# Call on module import (for EB deployment)
# IMPORTANT: This must be called AFTER all routes are defined
try:
    log_registered_routes()
    # Also print to stdout for Elastic Beanstalk logs
    print("=" * 60, flush=True)
    print("ROUTE REGISTRATION COMPLETE", flush=True)
    print("=" * 60, flush=True)
except Exception as e:
    logger.error(f"Error logging routes: {str(e)}")
    print(f"ERROR logging routes: {str(e)}", flush=True)
    import traceback
    traceback.print_exc()

if __name__ == '__main__':
    log_registered_routes()
    app.run(debug=False, host='0.0.0.0', port=5000)
