"""
AWS CodePipeline + CodeBuild Setup for Elastic Beanstalk with GitHub
Creates CI/CD pipeline that builds and deploys to Elastic Beanstalk from GitHub
"""
import boto3
import json
import sys
import time

# AWS Clients
codepipeline = boto3.client('codepipeline', region_name='eu-north-1')
codebuild = boto3.client('codebuild', region_name='eu-north-1')
codestar = boto3.client('codestar-connections', region_name='eu-north-1')
iam = boto3.client('iam')
s3_client = boto3.client('s3', region_name='eu-north-1')
eb = boto3.client('elasticbeanstalk', region_name='eu-north-1')

# Configuration
AWS_ACCOUNT_ID = boto3.client('sts').get_caller_identity()['Account']
AWS_REGION = 'eu-north-1'
PROJECT_NAME = 'InsuranceClaimApp'
APP_NAME = 'insurance-claim-app'
ENV_NAME = 'insurance-claim-app-single'
ARTIFACT_BUCKET = f'{APP_NAME}-pipeline-artifacts-{AWS_ACCOUNT_ID}'

print("="*80)
print("AWS CodePipeline + CodeBuild Setup for Elastic Beanstalk (GitHub)")
print("="*80)

# Step 1: Create S3 bucket for artifacts
print("\n[1/9] Creating S3 artifact bucket...")
try:
    s3_client.create_bucket(
        Bucket=ARTIFACT_BUCKET,
        CreateBucketConfiguration={'LocationConstraint': AWS_REGION}
    )
    s3_client.put_bucket_versioning(
        Bucket=ARTIFACT_BUCKET,
        VersioningConfiguration={'Status': 'Enabled'}
    )
    print(f"✓ Artifact bucket created: {ARTIFACT_BUCKET}")
except s3_client.exceptions.BucketAlreadyOwnedByYou:
    print(f"✓ Artifact bucket already exists: {ARTIFACT_BUCKET}")
except Exception as e:
    print(f"✗ Error creating artifact bucket: {str(e)}")
    sys.exit(1)

# Step 2: Create GitHub Connection (if needed)
print("\n[2/9] Setting up GitHub connection...")
print("NOTE: You need to create a GitHub connection in AWS CodeStar Connections first.")
print("Steps:")
print("1. Go to: https://console.aws.amazon.com/codesuite/codeconnections/home")
print("2. Click 'Create connection'")
print("3. Select 'GitHub'")
print("4. Click 'Connect to GitHub'")
print("5. Authorize AWS in GitHub")
print("6. Copy the Connection ARN")
print("\nEnter your GitHub Connection ARN (or press Enter to skip and configure later):")
connection_arn = input().strip()

if not connection_arn:
    print("⚠ Skipping GitHub connection setup. You'll need to:")
    print("  1. Create connection in CodeStar Connections console")
    print("  2. Update the pipeline Source action with the connection ARN")
    connection_arn = None
else:
    print(f"✓ Using GitHub connection: {connection_arn}")

# Step 3: Get GitHub Repository Info
print("\n[3/9] GitHub repository information...")
if connection_arn:
    print("Enter your GitHub repository owner (username or organization):")
    github_owner = input().strip()
    
    print("Enter your GitHub repository name:")
    github_repo = input().strip()
    
    print("Enter your GitHub branch (default: main):")
    github_branch = input().strip() or "main"
    
    print(f"✓ Repository: {github_owner}/{github_repo} (branch: {github_branch})")
else:
    github_owner = "YOUR_GITHUB_USERNAME"
    github_repo = "YOUR_REPO_NAME"
    github_branch = "main"
    print("⚠ Using placeholder values. Update after creating connection.")

# Step 4: Create IAM Roles
print("\n[4/9] Creating IAM roles...")

# CodePipeline Service Role
pipeline_role_name = 'CodePipelineServiceRole-InsuranceClaim'
pipeline_role_policy = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {"Service": "codepipeline.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }
    ]
}

pipeline_role_arn = None
try:
    response = iam.create_role(
        RoleName=pipeline_role_name,
        AssumeRolePolicyDocument=json.dumps(pipeline_role_policy),
        Description='Service role for CodePipeline'
    )
    pipeline_role_arn = response['Role']['Arn']
    print(f"✓ CodePipeline service role created: {pipeline_role_name}")
except iam.exceptions.EntityAlreadyExistsException:
    pipeline_role_arn = f'arn:aws:iam::{AWS_ACCOUNT_ID}:role/{pipeline_role_name}'
    print(f"✓ CodePipeline service role already exists: {pipeline_role_name}")

# Attach policies to CodePipeline role
pipeline_policies = [
    'arn:aws:iam::aws:policy/AWSCodePipeline_FullAccess',
    'arn:aws:iam::aws:policy/AmazonS3FullAccess',
    'arn:aws:iam::aws:policy/CloudWatchLogsFullAccess'
]

for policy_arn in pipeline_policies:
    try:
        iam.attach_role_policy(RoleName=pipeline_role_name, PolicyArn=policy_arn)
    except Exception as e:
        print(f"  Note: Policy attachment: {str(e)}")

# CodeBuild Service Role
codebuild_role_name = 'CodeBuildServiceRole-InsuranceClaim'
codebuild_role_policy = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {"Service": "codebuild.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }
    ]
}

codebuild_role_arn = None
try:
    response = iam.create_role(
        RoleName=codebuild_role_name,
        AssumeRolePolicyDocument=json.dumps(codebuild_role_policy),
        Description='Service role for CodeBuild'
    )
    codebuild_role_arn = response['Role']['Arn']
    print(f"✓ CodeBuild service role created: {codebuild_role_name}")
    
    # Wait a moment for the role to propagate
    import time
    time.sleep(2)
except iam.exceptions.EntityAlreadyExistsException:
    codebuild_role_arn = f'arn:aws:iam::{AWS_ACCOUNT_ID}:role/{codebuild_role_name}'
    print(f"✓ CodeBuild service role already exists: {codebuild_role_name}")
    
    # Verify trust policy is correct
    try:
        current_policy = iam.get_role(RoleName=codebuild_role_name)['Role']['AssumeRolePolicyDocument']
        if 'codebuild.amazonaws.com' not in str(current_policy):
            print(f"  ⚠ Updating trust policy...")
            iam.update_assume_role_policy(
                RoleName=codebuild_role_name,
                PolicyDocument=json.dumps(codebuild_role_policy)
            )
            time.sleep(2)
            print(f"  ✓ Trust policy updated")
    except Exception as e:
        print(f"  ⚠ Could not verify trust policy: {str(e)}")

# CodeBuild inline policy
codebuild_policy = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents",
                "s3:GetObject",
                "s3:PutObject",
                "s3:GetObjectVersion",
                "s3:GetBucketVersioning",
                "s3:PutObjectAcl",
                "codebuild:CreateReport",
                "codebuild:UpdateReport",
                "codebuild:BatchPutTestCases",
                "codebuild:BatchPutCodeCoverages",
                "elasticbeanstalk:*",
                "ec2:*",
                "iam:PassRole"
            ],
            "Resource": "*"
        }
    ]
}

try:
    iam.put_role_policy(
        RoleName=codebuild_role_name,
        PolicyName='CodeBuildPolicy',
        PolicyDocument=json.dumps(codebuild_policy)
    )
    print(f"✓ CodeBuild policy attached")
except Exception as e:
    print(f"  Note: Policy attachment: {str(e)}")

# Step 5: Create CodeBuild Project
print("\n[5/9] Creating CodeBuild project...")

codebuild_config = {
    'name': 'InsuranceClaimAppBuild',
    'description': 'Build project for Insurance Claim Management System',
    'source': {
        'type': 'GITHUB',
        'location': f'https://github.com/{github_owner}/{github_repo}.git',
        'buildspec': 'buildspec.yml'
    },
    'artifacts': {
        'type': 'S3',
        'location': ARTIFACT_BUCKET,
        'name': 'build-artifact',
        'packaging': 'ZIP'
    },
    'environment': {
        'type': 'LINUX_CONTAINER',
        'image': 'aws/codebuild/standard:7.0',
        'computeType': 'BUILD_GENERAL1_SMALL',
        'privilegedMode': False,
        'environmentVariables': [
            {'name': 'AWS_REGION', 'value': AWS_REGION},
            {'name': 'APP_NAME', 'value': APP_NAME},
            {'name': 'ENV_NAME', 'value': ENV_NAME}
        ]
    },
    'serviceRole': codebuild_role_arn,
    'timeoutInMinutes': 60
}

try:
    codebuild.create_project(**codebuild_config)
    print("✓ CodeBuild project created: InsuranceClaimAppBuild")
except codebuild.exceptions.ResourceAlreadyExistsException:
    print("✓ CodeBuild project already exists")
    # Update it
    codebuild.update_project(**codebuild_config)
    print("✓ CodeBuild project updated")
except Exception as e:
    print(f"✗ Error creating CodeBuild project: {str(e)}")
    print(f"  Note: You may need to update source location after setting up GitHub connection")

# Step 6: Create CodePipeline
print("\n[6/9] Creating CodePipeline...")

if connection_arn:
    source_action = {
        'name': 'SourceAction',
        'actionTypeId': {
            'category': 'Source',
            'owner': 'AWS',
            'provider': 'CodeStarSourceConnection',
            'version': '1'
        },
        'configuration': {
            'ConnectionArn': connection_arn,
            'FullRepositoryId': f'{github_owner}/{github_repo}',
            'BranchName': github_branch,
            'OutputArtifactFormat': 'CODE_ZIP'
        },
        'outputArtifacts': [{'name': 'SourceOutput'}]
    }
else:
    # Fallback to S3 for now
    source_action = {
        'name': 'SourceAction',
        'actionTypeId': {
            'category': 'Source',
            'owner': 'AWS',
            'provider': 'S3',
            'version': '1'
        },
        'configuration': {
            'S3Bucket': ARTIFACT_BUCKET,
            'S3ObjectKey': 'source.zip',
            'PollForSourceChanges': 'false'
        },
        'outputArtifacts': [{'name': 'SourceOutput'}]
    }

pipeline_config = {
    'name': 'InsuranceClaimAppPipeline',
    'roleArn': pipeline_role_arn,
    'artifactStore': {
        'type': 'S3',
        'location': ARTIFACT_BUCKET
    },
    'stages': [
        {
            'name': 'Source',
            'actions': [source_action]
        },
        {
            'name': 'Build',
            'actions': [
                {
                    'name': 'BuildAction',
                    'actionTypeId': {
                        'category': 'Build',
                        'owner': 'AWS',
                        'provider': 'CodeBuild',
                        'version': '1'
                    },
                    'configuration': {
                        'ProjectName': 'InsuranceClaimAppBuild'
                    },
                    'inputArtifacts': [{'name': 'SourceOutput'}],
                    'outputArtifacts': [{'name': 'BuildOutput'}]
                }
            ]
        },
        {
            'name': 'Deploy',
            'actions': [
                {
                    'name': 'DeployAction',
                    'actionTypeId': {
                        'category': 'Deploy',
                        'owner': 'AWS',
                        'provider': 'ElasticBeanstalk',
                        'version': '1'
                    },
                    'configuration': {
                        'ApplicationName': APP_NAME,
                        'EnvironmentName': ENV_NAME
                    },
                    'inputArtifacts': [{'name': 'BuildOutput'}]
                }
            ]
        }
    ]
}

try:
    codepipeline.create_pipeline(**pipeline_config)
    print("✓ CodePipeline created: InsuranceClaimAppPipeline")
except codepipeline.exceptions.PipelineNameInUseException:
    print("✓ CodePipeline already exists")
    # Update it
    codepipeline.update_pipeline(**pipeline_config)
    print("✓ CodePipeline updated")
except Exception as e:
    print(f"✗ Error creating CodePipeline: {str(e)}")
    print(f"  Details: {str(e)}")
    if not connection_arn:
        print("\n  NOTE: You may need to create GitHub connection first and update the pipeline.")

# Step 7: Summary
print("\n" + "="*80)
print("CI/CD Setup Complete!")
print("="*80)
print(f"\nPipeline Name: InsuranceClaimAppPipeline")
print(f"Build Project: InsuranceClaimAppBuild")
print(f"Artifact Bucket: {ARTIFACT_BUCKET}")
print(f"Deployment Target: {ENV_NAME}")

if connection_arn:
    print(f"\n✓ GitHub Connection: {connection_arn}")
    print(f"✓ Repository: {github_owner}/{github_repo}")
    print(f"✓ Branch: {github_branch}")
    print("\nThe pipeline will automatically trigger on pushes to GitHub!")
else:
    print("\n⚠ GitHub Connection: NOT CONFIGURED")
    print("\nNext Steps:")
    print("1. Create GitHub connection:")
    print("   https://console.aws.amazon.com/codesuite/codeconnections/home")
    print("2. Update pipeline Source action with connection ARN")
    print("3. Or run this script again with connection ARN")

print("\nView Pipeline:")
print("  https://console.aws.amazon.com/codesuite/codepipeline/pipelines/InsuranceClaimAppPipeline/view")

print("\nTest Pipeline:")
print("  aws codepipeline start-pipeline-execution --name InsuranceClaimAppPipeline")

