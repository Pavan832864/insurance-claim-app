#!/bin/bash
# Automated Deployment Script for S3-based CI/CD
# This script creates a zip, uploads to S3, and deploys to Elastic Beanstalk
# Usage: ./deploy_automated.sh

set -e

echo "=========================================="
echo "Automated Deployment to Elastic Beanstalk"
echo "=========================================="
echo ""



# Configuration
S3_BUCKET="elasticbeanstalk-eu-north-1-498048453643"
APP_NAME="insurance-claim-app"
ENV_NAME="insurance-claim-app-single"
REGION="eu-north-1"

echo "Step 1: Creating deployment package..."
zip -r deploy.zip app.py static/ .ebextensions/ requirements.txt claim_processor_library.py \
  -x "*.pyc" "__pycache__/*" "*.git/*" ".elasticbeanstalk/*" \
  > /dev/null 2>&1

if [ ! -f "deploy.zip" ]; then
    echo "❌ Error: Failed to create deploy.zip"
    exit 1
fi

SIZE=$(ls -lh deploy.zip | awk '{print $5}')
echo "✓ Package created: deploy.zip ($SIZE)"
echo ""

echo "Step 2: Uploading to S3..."
aws s3 cp deploy.zip s3://${S3_BUCKET}/deploy.zip --region ${REGION}

if [ $? -ne 0 ]; then
    echo "❌ Error: Failed to upload to S3"
    exit 1
fi

echo "✓ Uploaded to S3"
echo ""

echo "Step 3: Creating application version..."
VERSION_LABEL="deploy-$(date +%s)"
aws elasticbeanstalk create-application-version \
  --application-name ${APP_NAME} \
  --version-label ${VERSION_LABEL} \
  --source-bundle S3Bucket=${S3_BUCKET},S3Key=deploy.zip \
  --region ${REGION} \
  > /dev/null 2>&1

if [ $? -ne 0 ]; then
    echo "❌ Error: Failed to create application version"
    exit 1
fi

echo "✓ Application version created: ${VERSION_LABEL}"
echo ""

echo "Step 4: Deploying to environment..."
aws elasticbeanstalk update-environment \
  --application-name ${APP_NAME} \
  --environment-name ${ENV_NAME} \
  --version-label ${VERSION_LABEL} \
  --region ${REGION} \
  > /dev/null 2>&1

if [ $? -ne 0 ]; then
    echo "❌ Error: Failed to update environment"
    exit 1
fi

echo "✓ Deployment started"
echo ""

echo "=========================================="
echo "✅ Deployment Initiated!"
echo "=========================================="
echo ""
echo "Version Label: ${VERSION_LABEL}"
echo ""
echo "Monitor deployment:"
echo "  eb status ${ENV_NAME}"
echo ""
echo "Or check in console:"
echo "  https://console.aws.amazon.com/elasticbeanstalk/home?region=${REGION}#/environment/dashboard?applicationName=${APP_NAME}&environmentId=${ENV_NAME}"
echo ""

rm -f deploy.zip
echo "✓ Cleaned up local deploy.zip"
echo ""
echo "Deployment is in progress. Check status with: eb status ${ENV_NAME}"

