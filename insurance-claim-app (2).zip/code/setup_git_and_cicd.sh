#!/bin/bash

echo "=========================================="
echo "Git & CI/CD Setup Script"
echo "=========================================="
echo ""

# Step 1: Configure Git
echo "Step 1: Configure Git with your GitHub account"
echo ""
read -p "Enter your GitHub username: " GITHUB_USERNAME
read -p "Enter your GitHub email: " GITHUB_EMAIL
read -p "Enter your repository name: " REPO_NAME
read -p "Enter your branch name (default: main): " BRANCH_NAME
BRANCH_NAME=${BRANCH_NAME:-main}

echo ""
echo "Configuring Git..."
git config --global user.name "$GITHUB_USERNAME"
git config --global user.email "$GITHUB_EMAIL"

echo "✓ Git configured:"
echo "  Username: $(git config --global user.name)"
echo "  Email: $(git config --global user.email)"
echo ""

# Step 2: Initialize Git (if not already)
if [ ! -d .git ]; then
    echo "Step 2: Initializing Git repository..."
    git init
    echo "✓ Git repository initialized"
else
    echo "Step 2: Git repository already initialized"
fi
echo ""

# Step 3: Add remote
echo "Step 3: Setting up GitHub remote..."
if git remote get-url origin &>/dev/null; then
    echo "Remote 'origin' already exists:"
    git remote -v
    read -p "Do you want to update it? (y/n): " UPDATE_REMOTE
    if [ "$UPDATE_REMOTE" = "y" ]; then
        git remote set-url origin "https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"
        echo "✓ Remote updated"
    fi
else
    git remote add origin "https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"
    echo "✓ Remote added: https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"
fi
echo ""

# Step 4: Verify remote
echo "Step 4: Verifying remote..."
git remote -v
echo ""

# Step 5: Summary
echo "=========================================="
echo "Setup Complete!"
echo "=========================================="
echo ""
echo "Git Configuration:"
echo "  Username: $GITHUB_USERNAME"
echo "  Email: $GITHUB_EMAIL"
echo ""
echo "Repository:"
echo "  Owner: $GITHUB_USERNAME"
echo "  Name: $REPO_NAME"
echo "  Branch: $BRANCH_NAME"
echo "  URL: https://github.com/$GITHUB_USERNAME/$REPO_NAME.git"
echo ""
echo "Next Steps:"
echo "1. Add and commit your files:"
echo "   git add ."
echo "   git commit -m 'Initial commit'"
echo ""
echo "2. Push to GitHub:"
echo "   git branch -M $BRANCH_NAME"
echo "   git push -u origin $BRANCH_NAME"
echo ""
echo "3. Run CI/CD setup:"
echo "   python3.11 setup_cicd_github.py"
echo "   (You'll need the GitHub Connection ARN from AWS CodeStar Connections)"
echo ""

