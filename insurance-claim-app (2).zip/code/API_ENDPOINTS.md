# API Endpoints Documentation

## Base URL
```
http://insurance-claim-app-single.eba-neqfphnn.eu-north-1.elasticbeanstalk.com
```

## Available Endpoints

### 1. Root Endpoint
**GET /** - API Information
```bash
curl http://insurance-claim-app-single.eba-neqfphnn.eu-north-1.elasticbeanstalk.com/
```

**Response:**
```json
{
  "success": true,
  "message": "Insurance Claim Management System API",
  "version": "1.0",
  "endpoints": {
    "health": "/health",
    "create_claim": "POST /api/claims",
    "get_claims": "GET /api/claims",
    "get_claim": "GET /api/claims/<claim_id>",
    "update_claim": "PUT /api/claims/<claim_id>",
    "delete_claim": "DELETE /api/claims/<claim_id>",
    "upload_documents": "POST /api/claims/<claim_id>/documents",
    "get_stats": "GET /api/stats"
  }
}
```

### 2. Health Check
**GET /health**
```bash
curl http://insurance-claim-app-single.eba-neqfphnn.eu-north-1.elasticbeanstalk.com/health
```

### 3. Create Claim
**POST /api/claims**
```bash
curl -X POST http://insurance-claim-app-single.eba-neqfphnn.eu-north-1.elasticbeanstalk.com/api/claims \
  -H "Content-Type: application/json" \
  -d '{
    "customer_name": "John Doe",
    "email": "john@example.com",
    "policy_number": "POL123456",
    "claim_type": "Vehicle",
    "amount": 5000,
    "incident_date": "2024-01-15",
    "description": "Car accident on highway"
  }'
```

### 4. Get All Claims
**GET /api/claims**
```bash
# Get all claims
curl http://insurance-claim-app-single.eba-neqfphnn.eu-north-1.elasticbeanstalk.com/api/claims

# Filter by status
curl http://insurance-claim-app-single.eba-neqfphnn.eu-north-1.elasticbeanstalk.com/api/claims?status=Pending

# Filter by customer email
curl http://insurance-claim-app-single.eba-neqfphnn.eu-north-1.elasticbeanstalk.com/api/claims?email=john@example.com
```

### 5. Get Specific Claim
**GET /api/claims/<claim_id>**
```bash
curl http://insurance-claim-app-single.eba-neqfphnn.eu-north-1.elasticbeanstalk.com/api/claims/CLM-20241108-12345678
```

### 6. Update Claim
**PUT /api/claims/<claim_id>**
```bash
curl -X PUT http://insurance-claim-app-single.eba-neqfphnn.eu-north-1.elasticbeanstalk.com/api/claims/CLM-20241108-12345678 \
  -H "Content-Type: application/json" \
  -d '{
    "status": "Approved",
    "admin_notes": "Claim approved after review"
  }'
```

### 7. Delete Claim
**DELETE /api/claims/<claim_id>**
```bash
curl -X DELETE http://insurance-claim-app-single.eba-neqfphnn.eu-north-1.elasticbeanstalk.com/api/claims/CLM-20241108-12345678
```

### 8. Upload Documents
**POST /api/claims/<claim_id>/documents**
```bash
curl -X POST http://insurance-claim-app-single.eba-neqfphnn.eu-north-1.elasticbeanstalk.com/api/claims/CLM-20241108-12345678/documents \
  -F "files=@document.pdf"
```

### 9. Get Statistics
**GET /api/stats**
```bash
curl http://insurance-claim-app-single.eba-neqfphnn.eu-north-1.elasticbeanstalk.com/api/stats
```

## Error Responses

All endpoints return errors in this format:
```json
{
  "success": false,
  "error": "Error message"
}
```

## Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request (validation errors)
- `404` - Not Found
- `500` - Internal Server Error

