"""
AWS Setup Script for Insurance Claim Management System
Configures DynamoDB tables, S3 buckets, and IAM roles
"""

import boto3
import json
import os
from botocore.exceptions import ClientError
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AWSSetup:
    def __init__(self, region='eu-north-1'):
        self.region = region
        self.dynamodb = boto3.client('dynamodb', region_name=region)
        self.s3 = boto3.client('s3', region_name=region)
        self.iam = boto3.client('iam', region_name=region)
        self.cloudwatch = boto3.client('cloudwatch', region_name=region)
    
    def create_dynamodb_table(self, table_name='insurance-claims'):
        """Create DynamoDB table for claims"""
        try:
            response = self.dynamodb.create_table(
                TableName=table_name,
                KeySchema=[
                    {
                        'AttributeName': 'claim_id',
                        'KeyType': 'HASH'  # Partition key
                    }
                ],
                AttributeDefinitions=[
                    {
                        'AttributeName': 'claim_id',
                        'AttributeType': 'S'
                    },
                    {
                        'AttributeName': 'status',
                        'AttributeType': 'S'
                    },
                    {
                        'AttributeName': 'created_at',
                        'AttributeType': 'S'
                    }
                ],
                BillingMode='PAY_PER_REQUEST',
                GlobalSecondaryIndexes=[
                    {
                        'IndexName': 'status-created_at-index',
                        'KeySchema': [
                            {'AttributeName': 'status', 'KeyType': 'HASH'},
                            {'AttributeName': 'created_at', 'KeyType': 'RANGE'}
                        ],
                        'Projection': {'ProjectionType': 'ALL'}
                    }
                ],
                StreamSpecification={
                    'StreamViewType': 'NEW_AND_OLD_IMAGES'
                },
                Tags=[
                    {'Key': 'Application', 'Value': 'InsuranceClaimApp'},
                    {'Key': 'Environment', 'Value': 'Production'}
                ]
            )
            logger.info(f"DynamoDB table '{table_name}' created successfully")
            return response
        except ClientError as e:
            if e.response['Error']['Code'] == 'ResourceInUseException':
                logger.info(f"Table '{table_name}' already exists")
            else:
                logger.error(f"Error creating DynamoDB table: {str(e)}")
                raise
    
    def create_s3_bucket(self, bucket_name='insurance-claims-bucket'):
        """Create S3 bucket for document storage"""
        try:
            if self.region == 'us-east-1':
                response = self.s3.create_bucket(Bucket=bucket_name)
            else:
                response = self.s3.create_bucket(
                    Bucket=bucket_name,
                    CreateBucketConfiguration={'LocationConstraint': self.region}
                )
            logger.info(f"S3 bucket '{bucket_name}' created successfully")
            
            # Block public access
            self.s3.put_public_access_block(
                Bucket=bucket_name,
                PublicAccessBlockConfiguration={
                    'BlockPublicAcls': True,
                    'BlockPublicPolicy': True,
                    'IgnorePublicAcls': True,
                    'RestrictPublicBuckets': True
                }
            )
            
            # Enable versioning
            self.s3.put_bucket_versioning(
                Bucket=bucket_name,
                VersioningConfiguration={'Status': 'Enabled'}
            )
            
            # Set lifecycle policy
            self.s3.put_bucket_lifecycle_configuration(
                Bucket=bucket_name,
                LifecycleConfiguration={
                    'Rules': [
                        {
                            'Id': 'archive-old-documents',
                            'Status': 'Enabled',
                            'Prefix': 'claims/',
                            'Transitions': [
                                {'Days': 90, 'StorageClass': 'GLACIER'}
                            ],
                            'Expiration': {'Days': 2555}
                        }
                    ]
                }
            )
            
            logger.info(f"S3 bucket '{bucket_name}' configured with security and lifecycle policies")
            return response
        except ClientError as e:
            if e.response['Error']['Code'] == 'BucketAlreadyOwnedByYou':
                logger.info(f"Bucket '{bucket_name}' already exists")
            elif e.response['Error']['Code'] == 'BucketAlreadyExists':
                logger.error(f"Bucket '{bucket_name}' already owned by another account")
            else:
                logger.error(f"Error creating S3 bucket: {str(e)}")
            raise
    
    def create_iam_role(self, role_name='insurance-claim-app-role'):
        """Create IAM role for application"""
        try:
            assume_role_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Principal": {
                            "Service": [
                                "ec2.amazonaws.com",
                                "ecs-tasks.amazonaws.com",
                                "elasticbeanstalk.amazonaws.com"
                            ]
                        },
                        "Action": "sts:AssumeRole"
                    }
                ]
            }
            
            response = self.iam.create_role(
                RoleName=role_name,
                AssumeRolePolicyDocument=json.dumps(assume_role_policy),
                Description='Role for Insurance Claim Management System'
            )
            logger.info(f"IAM role '{role_name}' created successfully")
            
            # Attach DynamoDB policy
            dynamodb_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": [
                            "dynamodb:GetItem",
                            "dynamodb:PutItem",
                            "dynamodb:UpdateItem",
                            "dynamodb:DeleteItem",
                            "dynamodb:Query",
                            "dynamodb:Scan"
                        ],
                        "Resource": "arn:aws:dynamodb:*:*:table/insurance-claims*"
                    }
                ]
            }
            
            self.iam.put_role_policy(
                RoleName=role_name,
                PolicyName='dynamodb-access',
                PolicyDocument=json.dumps(dynamodb_policy)
            )
            
            # Attach S3 policy
            s3_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": [
                            "s3:GetObject",
                            "s3:PutObject",
                            "s3:DeleteObject",
                            "s3:ListBucket"
                        ],
                        "Resource": [
                            "arn:aws:s3:::insurance-claims-bucket",
                            "arn:aws:s3:::insurance-claims-bucket/*"
                        ]
                    }
                ]
            }
            
            self.iam.put_role_policy(
                RoleName=role_name,
                PolicyName='s3-access',
                PolicyDocument=json.dumps(s3_policy)
            )
            
            # Attach CloudWatch Logs policy
            logs_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": [
                            "logs:CreateLogGroup",
                            "logs:CreateLogStream",
                            "logs:PutLogEvents"
                        ],
                        "Resource": "arn:aws:logs:*:*:*"
                    }
                ]
            }
            
            self.iam.put_role_policy(
                RoleName=role_name,
                PolicyName='cloudwatch-logs',
                PolicyDocument=json.dumps(logs_policy)
            )
            
            logger.info(f"Policies attached to role '{role_name}'")
            return response
        except ClientError as e:
            if e.response['Error']['Code'] == 'EntityAlreadyExists':
                logger.info(f"IAM role '{role_name}' already exists")
            else:
                logger.error(f"Error creating IAM role: {str(e)}")
            raise
    
    def setup_all(self):
        """Run complete AWS setup"""
        logger.info("Starting AWS setup for Insurance Claim Management System...")
        try:
            self.create_dynamodb_table()
            self.create_s3_bucket()
            self.create_iam_role()
            logger.info("AWS setup completed successfully!")
        except Exception as e:
            logger.error(f"AWS setup failed: {str(e)}")
            raise

if __name__ == '__main__':
    setup = AWSSetup(region=os.getenv('AWS_REGION', 'eu-north-1'))
    setup.setup_all()
