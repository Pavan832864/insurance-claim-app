"""
AWS CodePipeline + CodeBuild Setup for Elastic Beanstalk
Creates CI/CD pipeline that builds and deploys to Elastic Beanstalk
"""
import boto3
import json
import sys
import time

# AWS Clients
codepipeline = boto3.client('codepipeline', region_name='eu-north-1')
codebuild = boto3.client('codebuild', region_name='eu-north-1')
iam = boto3.client('iam')
s3_client = boto3.client('s3', region_name='eu-north-1')
eb = boto3.client('elasticbeanstalk', region_name='eu-north-1')

# Configuration
AWS_ACCOUNT_ID = boto3.client('sts').get_caller_identity()['Account']
AWS_REGION = 'eu-north-1'
PROJECT_NAME = 'InsuranceClaimApp'
APP_NAME = 'insurance-claim-app'
ENV_NAME = 'insurance-claim-app-single'
ARTIFACT_BUCKET = f'{APP_NAME}-pipeline-artifacts-{AWS_ACCOUNT_ID}'

print("="*80)
print("AWS CodePipeline + CodeBuild Setup for Elastic Beanstalk")
print("="*80)

# Step 1: Create S3 bucket for artifacts
print("\n[1/8] Creating S3 artifact bucket...")
try:
    s3_client.create_bucket(
        Bucket=ARTIFACT_BUCKET,
        CreateBucketConfiguration={'LocationConstraint': AWS_REGION}
    )
    s3_client.put_bucket_versioning(
        Bucket=ARTIFACT_BUCKET,
        VersioningConfiguration={'Status': 'Enabled'}
    )
    print(f"✓ Artifact bucket created: {ARTIFACT_BUCKET}")
except s3_client.exceptions.BucketAlreadyOwnedByYou:
    print(f"✓ Artifact bucket already exists: {ARTIFACT_BUCKET}")
except Exception as e:
    print(f"✗ Error creating artifact bucket: {str(e)}")
    sys.exit(1)

# Step 2: Create IAM Roles
print("\n[2/8] Creating IAM roles...")

# CodePipeline Service Role
pipeline_role_name = 'CodePipelineServiceRole-InsuranceClaim'
pipeline_role_policy = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {"Service": "codepipeline.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }
    ]
}

pipeline_role_arn = None
try:
    response = iam.create_role(
        RoleName=pipeline_role_name,
        AssumeRolePolicyDocument=json.dumps(pipeline_role_policy),
        Description='Service role for CodePipeline'
    )
    pipeline_role_arn = response['Role']['Arn']
    print(f"✓ CodePipeline service role created: {pipeline_role_name}")
except iam.exceptions.EntityAlreadyExistsException:
    pipeline_role_arn = f'arn:aws:iam::{AWS_ACCOUNT_ID}:role/{pipeline_role_name}'
    print(f"✓ CodePipeline service role already exists: {pipeline_role_name}")

# Attach policies to CodePipeline role
pipeline_policies = [
    'arn:aws:iam::aws:policy/AWSCodePipeline_FullAccess',
    'arn:aws:iam::aws:policy/AmazonS3FullAccess',
    'arn:aws:iam::aws:policy/CloudWatchLogsFullAccess'
]

for policy_arn in pipeline_policies:
    try:
        iam.attach_role_policy(RoleName=pipeline_role_name, PolicyArn=policy_arn)
    except Exception as e:
        print(f"  Note: Policy attachment: {str(e)}")

# CodeBuild Service Role
codebuild_role_name = 'CodeBuildServiceRole-InsuranceClaim'
codebuild_role_policy = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {"Service": "codebuild.amazonaws.com"},
            "Action": "sts:AssumeRole"
        }
    ]
}

codebuild_role_arn = None
try:
    response = iam.create_role(
        RoleName=codebuild_role_name,
        AssumeRolePolicyDocument=json.dumps(codebuild_role_policy),
        Description='Service role for CodeBuild'
    )
    codebuild_role_arn = response['Role']['Arn']
    print(f"✓ CodeBuild service role created: {codebuild_role_name}")
    
    # Wait a moment for the role to propagate
    import time
    time.sleep(2)
except iam.exceptions.EntityAlreadyExistsException:
    codebuild_role_arn = f'arn:aws:iam::{AWS_ACCOUNT_ID}:role/{codebuild_role_name}'
    print(f"✓ CodeBuild service role already exists: {codebuild_role_name}")
    
    # Verify trust policy is correct
    try:
        current_policy = iam.get_role(RoleName=codebuild_role_name)['Role']['AssumeRolePolicyDocument']
        if 'codebuild.amazonaws.com' not in str(current_policy):
            print(f"  ⚠ Updating trust policy...")
            iam.update_assume_role_policy(
                RoleName=codebuild_role_name,
                PolicyDocument=json.dumps(codebuild_role_policy)
            )
            time.sleep(2)
            print(f"  ✓ Trust policy updated")
    except Exception as e:
        print(f"  ⚠ Could not verify trust policy: {str(e)}")

# CodeBuild inline policy
codebuild_policy = {
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents",
                "s3:GetObject",
                "s3:PutObject",
                "s3:GetObjectVersion",
                "s3:GetBucketVersioning",
                "s3:PutObjectAcl",
                "codebuild:CreateReport",
                "codebuild:UpdateReport",
                "codebuild:BatchPutTestCases",
                "codebuild:BatchPutCodeCoverages",
                "elasticbeanstalk:*",
                "ec2:*",
                "iam:PassRole"
            ],
            "Resource": "*"
        }
    ]
}

try:
    iam.put_role_policy(
        RoleName=codebuild_role_name,
        PolicyName='CodeBuildPolicy',
        PolicyDocument=json.dumps(codebuild_policy)
    )
    print(f"✓ CodeBuild policy attached")
except Exception as e:
    print(f"  Note: Policy attachment: {str(e)}")

# Step 3: Create CodeBuild Project
print("\n[3/8] Creating CodeBuild project...")

codebuild_config = {
    'name': 'InsuranceClaimAppBuild',
    'description': 'Build project for Insurance Claim Management System',
    'source': {
        'type': 'S3',
        'location': f'{ARTIFACT_BUCKET}/source.zip'
    },
    'artifacts': {
        'type': 'S3',
        'location': ARTIFACT_BUCKET,
        'name': 'build-artifact',
        'packaging': 'ZIP'
    },
    'environment': {
        'type': 'LINUX_CONTAINER',
        'image': 'aws/codebuild/standard:7.0',
        'computeType': 'BUILD_GENERAL1_SMALL',
        'privilegedMode': False,
        'environmentVariables': [
            {'name': 'AWS_REGION', 'value': AWS_REGION},
            {'name': 'APP_NAME', 'value': APP_NAME},
            {'name': 'ENV_NAME', 'value': ENV_NAME}
        ]
    },
    'serviceRole': codebuild_role_arn,
    'timeoutInMinutes': 60
}

try:
    codebuild.create_project(**codebuild_config)
    print("✓ CodeBuild project created: InsuranceClaimAppBuild")
except codebuild.exceptions.ResourceAlreadyExistsException:
    print("✓ CodeBuild project already exists")
    # Update it
    codebuild.update_project(**codebuild_config)
    print("✓ CodeBuild project updated")
except Exception as e:
    print(f"✗ Error creating CodeBuild project: {str(e)}")
    print(f"  Details: {str(e)}")
    sys.exit(1)

# Step 4: Create CodePipeline
print("\n[4/8] Creating CodePipeline...")

# Note: For GitHub integration, you'll need to:
# 1. Create a GitHub connection in AWS CodeStar Connections
# 2. Update the Source action to use GitHub instead of S3

pipeline_config = {
    'name': 'InsuranceClaimAppPipeline',
    'roleArn': pipeline_role_arn,
    'artifactStore': {
        'type': 'S3',
        'location': ARTIFACT_BUCKET
    },
    'stages': [
        {
            'name': 'Source',
            'actions': [
                {
                    'name': 'SourceAction',
                    'actionTypeId': {
                        'category': 'Source',
                        'owner': 'AWS',
                        'provider': 'S3',  # Change to GitHub after setting up connection
                        'version': '1'
                    },
                    'configuration': {
                        'S3Bucket': ARTIFACT_BUCKET,
                        'S3ObjectKey': 'source.zip',
                        'PollForSourceChanges': 'false'
                        # For GitHub, use:
                        # 'Owner': 'your-github-username',
                        # 'Repo': 'your-repo-name',
                        # 'Branch': 'main',
                        # 'ConnectionArn': 'arn:aws:codestar-connections:...'
                    },
                    'outputArtifacts': [{'name': 'SourceOutput'}]
                }
            ]
        },
        {
            'name': 'Build',
            'actions': [
                {
                    'name': 'BuildAction',
                    'actionTypeId': {
                        'category': 'Build',
                        'owner': 'AWS',
                        'provider': 'CodeBuild',
                        'version': '1'
                    },
                    'configuration': {
                        'ProjectName': 'InsuranceClaimAppBuild'
                    },
                    'inputArtifacts': [{'name': 'SourceOutput'}],
                    'outputArtifacts': [{'name': 'BuildOutput'}]
                }
            ]
        },
        {
            'name': 'Deploy',
            'actions': [
                {
                    'name': 'DeployAction',
                    'actionTypeId': {
                        'category': 'Deploy',
                        'owner': 'AWS',
                        'provider': 'ElasticBeanstalk',
                        'version': '1'
                    },
                    'configuration': {
                        'ApplicationName': APP_NAME,
                        'EnvironmentName': ENV_NAME
                    },
                    'inputArtifacts': [{'name': 'BuildOutput'}]
                }
            ]
        }
    ]
}

try:
    codepipeline.create_pipeline(pipeline=pipeline_config)
    print("✓ CodePipeline created: InsuranceClaimAppPipeline")
except codepipeline.exceptions.PipelineNameInUseException:
    print("✓ CodePipeline already exists")
    # Update it
    codepipeline.update_pipeline(pipeline=pipeline_config)
    print("✓ CodePipeline updated")
except Exception as e:
    print(f"✗ Error creating CodePipeline: {str(e)}")
    print(f"  Details: {str(e)}")
    sys.exit(1)

print("\n" + "="*80)
print("CI/CD Setup Complete!")
print("="*80)
print(f"\nPipeline Name: InsuranceClaimAppPipeline")
print(f"Build Project: InsuranceClaimAppBuild")
print(f"Artifact Bucket: {ARTIFACT_BUCKET}")
print(f"\nNext Steps:")
print("1. Set up GitHub connection (if using GitHub):")
print("   - Go to AWS CodeStar Connections console")
print("   - Create a new connection to GitHub")
print("   - Update the pipeline Source action with the connection ARN")
print("\n2. For manual trigger, upload source.zip to S3:")
print(f"   aws s3 cp source.zip s3://{ARTIFACT_BUCKET}/source.zip")
print("\n3. View pipeline:")
print("   aws codepipeline get-pipeline --name InsuranceClaimAppPipeline")
print("\n4. Start pipeline execution:")
print("   aws codepipeline start-pipeline-execution --name InsuranceClaimAppPipeline")

