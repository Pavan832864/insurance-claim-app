#!/bin/bash
# Quick Deploy Script for S3-based CI/CD
# Usage: ./deploy.sh

set -e

echo "=========================================="
echo "Deploying to Elastic Beanstalk via CI/CD"
echo "=========================================="
echo ""


echo "Step 1: Creating deployment package..."
zip -r source.zip app.py static/ .ebextensions/ requirements.txt claim_processor_library.py \
  -x "*.pyc" "__pycache__/*" "*.git/*" ".elasticbeanstalk/*" \
  > /dev/null 2>&1

if [ ! -f "source.zip" ]; then
    echo "❌ Error: Failed to create source.zip"
    exit 1
fi

SIZE=$(ls -lh source.zip | awk '{print $5}')
echo "✓ Package created: source.zip ($SIZE)"
echo ""

echo "Step 2: Uploading to S3..."
aws s3 cp source.zip s3://insurance-claim-app-pipeline-artifacts-498048453643/source.zip --region eu-north-1

if [ $? -ne 0 ]; then
    echo "❌ Error: Failed to upload to S3"
    exit 1
fi

echo "✓ Uploaded to S3"
echo ""

echo "Step 3: Triggering pipeline..."
EXECUTION_ID=$(aws codepipeline start-pipeline-execution \
  --name InsuranceClaimAppPipeline \
  --region eu-north-1 \
  --query 'pipelineExecutionId' \
  --output text)

if [ $? -ne 0 ]; then
    echo "❌ Error: Failed to trigger pipeline"
    exit 1
fi

echo "✓ Pipeline triggered"
echo ""
echo "=========================================="
echo "Deployment Started!"
echo "=========================================="
echo ""
echo "Pipeline Execution ID: $EXECUTION_ID"
echo ""
echo "View pipeline status:"
echo "https://console.aws.amazon.com/codesuite/codepipeline/pipelines/InsuranceClaimAppPipeline/view"
echo ""
echo "Monitor progress:"
echo "  aws codepipeline get-pipeline-state --name InsuranceClaimAppPipeline --region eu-north-1"
echo ""
echo "Check Elastic Beanstalk:"
echo "  eb status"
echo ""

rm -f source.zip
echo "✓ Cleaned up local source.zip"
