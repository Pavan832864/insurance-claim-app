"""
Complete AWS Infrastructure Setup Script
Sets up all required AWS services for Insurance Claim Management System:
- DynamoDB (claims storage)
- S3 (document storage)
- Elastic Beanstalk (application hosting)
- RDS (optional - MySQL/PostgreSQL for additional data)
- IAM (roles and permissions)
- CloudWatch (monitoring and logging)
- CodePipeline/CodeBuild/CodeDeploy (CI/CD)
"""

import boto3
import json
import os
import time
from botocore.exceptions import ClientError
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class CompleteAWSSetup:
    def __init__(self, region='eu-north-1'):
        self.region = region
        self.dynamodb = boto3.client('dynamodb', region_name=region)
        self.s3 = boto3.client('s3', region_name=region)
        self.iam = boto3.client('iam')
        self.cloudwatch = boto3.client('cloudwatch', region_name=region)
        self.elasticbeanstalk = boto3.client('elasticbeanstalk', region_name=region)
        self.rds = boto3.client('rds', region_name=region)
        self.codepipeline = boto3.client('codepipeline', region_name=region)
        self.codebuild = boto3.client('codebuild', region_name=region)
        self.codedeploy = boto3.client('codedeploy', region_name=region)
        self.sts = boto3.client('sts')
        
        # Get AWS account ID
        try:
            self.account_id = self.sts.get_caller_identity()['Account']
        except Exception as e:
            logger.error(f"Error getting AWS account ID: {str(e)}")
            self.account_id = None
    
    def create_dynamodb_table(self, table_name='insurance-claims'):
        """Create DynamoDB table for claims"""
        try:
            response = self.dynamodb.create_table(
                TableName=table_name,
                KeySchema=[
                    {'AttributeName': 'claim_id', 'KeyType': 'HASH'}
                ],
                AttributeDefinitions=[
                    {'AttributeName': 'claim_id', 'AttributeType': 'S'},
                    {'AttributeName': 'status', 'AttributeType': 'S'},
                    {'AttributeName': 'created_at', 'AttributeType': 'S'}
                ],
                BillingMode='PAY_PER_REQUEST',
                GlobalSecondaryIndexes=[
                    {
                        'IndexName': 'status-created_at-index',
                        'KeySchema': [
                            {'AttributeName': 'status', 'KeyType': 'HASH'},
                            {'AttributeName': 'created_at', 'KeyType': 'RANGE'}
                        ],
                        'Projection': {'ProjectionType': 'ALL'}
                    }
                ],
                StreamSpecification={
                    'StreamEnabled': True,
                    'StreamViewType': 'NEW_AND_OLD_IMAGES'
                },
                SSESpecification={'Enabled': True, 'SSEType': 'KMS'},
                Tags=[
                    {'Key': 'Application', 'Value': 'InsuranceClaimApp'},
                    {'Key': 'Environment', 'Value': 'Production'}
                ]
            )
            logger.info(f"✓ DynamoDB table '{table_name}' created with encryption")
            return response
        except ClientError as e:
            if e.response['Error']['Code'] == 'ResourceInUseException':
                logger.info(f"✓ DynamoDB table '{table_name}' already exists")
            else:
                logger.error(f"✗ Error creating DynamoDB table: {str(e)}")
                raise
    
    def create_s3_bucket(self, bucket_name='claim-insurance-buck-et'):
        """Create S3 bucket with encryption and security"""
        try:
            if self.region == 'us-east-1':
                self.s3.create_bucket(Bucket=bucket_name)
            else:
                self.s3.create_bucket(
                    Bucket=bucket_name,
                    CreateBucketConfiguration={'LocationConstraint': self.region}
                )
            logger.info(f"✓ S3 bucket '{bucket_name}' created")
            
            # Enable encryption
            self.s3.put_bucket_encryption(
                Bucket=bucket_name,
                ServerSideEncryptionConfiguration={
                    'Rules': [
                        {
                            'ApplyServerSideEncryptionByDefault': {
                                'SSEAlgorithm': 'AES256'
                            }
                        }
                    ]
                }
            )
            
            # Block public access
            self.s3.put_public_access_block(
                Bucket=bucket_name,
                PublicAccessBlockConfiguration={
                    'BlockPublicAcls': True,
                    'BlockPublicPolicy': True,
                    'IgnorePublicAcls': True,
                    'RestrictPublicBuckets': True
                }
            )
            
            # Enable versioning
            self.s3.put_bucket_versioning(
                Bucket=bucket_name,
                VersioningConfiguration={'Status': 'Enabled'}
            )
            
            # Set lifecycle policy
            self.s3.put_bucket_lifecycle_configuration(
                Bucket=bucket_name,
                LifecycleConfiguration={
                    'Rules': [
                        {
                            'Id': 'archive-old-documents',
                            'Status': 'Enabled',
                            'Prefix': 'claims/',
                            'Transitions': [
                                {'Days': 90, 'StorageClass': 'GLACIER'}
                            ],
                            'Expiration': {'Days': 2555}
                        }
                    ]
                }
            )
            
            logger.info(f"✓ S3 bucket '{bucket_name}' configured with encryption and security")
            return True
        except ClientError as e:
            if e.response['Error']['Code'] == 'BucketAlreadyOwnedByYou':
                logger.info(f"✓ S3 bucket '{bucket_name}' already exists")
                return True
            else:
                logger.error(f"✗ Error creating S3 bucket: {str(e)}")
                raise
    
    def create_rds_instance(self, db_instance_id='insurance-claims-db', 
                          db_name='insurance_claims', 
                          master_username='admin',
                          master_password=None):
        """Create RDS PostgreSQL instance (optional - for additional data storage)"""
        if not master_password:
            logger.warning("⚠ RDS master password not provided. Skipping RDS creation.")
            logger.info("💡 Note: Using DynamoDB as primary database. RDS is optional.")
            return None
        
        try:
            response = self.rds.create_db_instance(
                DBInstanceIdentifier=db_instance_id,
                DBName=db_name,
                DBInstanceClass='db.t3.micro',
                Engine='postgres',
                MasterUsername=master_username,
                MasterUserPassword=master_password,
                AllocatedStorage=20,
                StorageType='gp2',
                StorageEncrypted=True,
                BackupRetentionPeriod=7,
                MultiAZ=False,
                PubliclyAccessible=False,
                VpcSecurityGroupIds=[],  # Will be set by Elastic Beanstalk
                DBSubnetGroupName='default',
                Tags=[
                    {'Key': 'Application', 'Value': 'InsuranceClaimApp'},
                    {'Key': 'Environment', 'Value': 'Production'}
                ]
            )
            logger.info(f"✓ RDS PostgreSQL instance '{db_instance_id}' created")
            logger.info("⏳ RDS instance is being created. This may take 5-10 minutes.")
            return response
        except ClientError as e:
            if 'already exists' in str(e).lower():
                logger.info(f"✓ RDS instance '{db_instance_id}' already exists")
            else:
                logger.error(f"✗ Error creating RDS instance: {str(e)}")
                raise
    
    def create_iam_roles(self):
        """Create IAM roles for Admin, Customer, and Application"""
        roles_created = []
        
        # Application Role (for Elastic Beanstalk)
        app_role_policy = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Principal": {
                        "Service": ["ec2.amazonaws.com", "elasticbeanstalk.amazonaws.com"]
                    },
                    "Action": "sts:AssumeRole"
                }
            ]
        }
        
        try:
            self.iam.create_role(
                RoleName='InsuranceClaimApp-Role',
                AssumeRolePolicyDocument=json.dumps(app_role_policy),
                Description='Role for Insurance Claim Management Application'
            )
            logger.info("✓ Application IAM role created")
            roles_created.append('InsuranceClaimApp-Role')
        except ClientError as e:
            if e.response['Error']['Code'] == 'EntityAlreadyExists':
                logger.info("✓ Application IAM role already exists")
            else:
                logger.error(f"✗ Error creating application role: {str(e)}")
        
        # Attach policies to application role
        app_policies = {
            'DynamoDBAccess': {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": [
                            "dynamodb:GetItem", "dynamodb:PutItem",
                            "dynamodb:UpdateItem", "dynamodb:DeleteItem",
                            "dynamodb:Query", "dynamodb:Scan"
                        ],
                        "Resource": f"arn:aws:dynamodb:{self.region}:*:table/insurance-claims*"
                    }
                ]
            },
            'S3Access': {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": [
                            "s3:GetObject", "s3:PutObject",
                            "s3:DeleteObject", "s3:ListBucket"
                        ],
                        "Resource": [
                            f"arn:aws:s3:::claim-insurance-buck-et",
                            f"arn:aws:s3:::claim-insurance-buck-et/*"
                        ]
                    }
                ]
            },
            'CloudWatchLogs': {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": [
                            "logs:CreateLogGroup", "logs:CreateLogStream",
                            "logs:PutLogEvents", "logs:DescribeLogStreams"
                        ],
                        "Resource": "arn:aws:logs:*:*:*"
                    }
                ]
            }
        }
        
        for policy_name, policy_doc in app_policies.items():
            try:
                self.iam.put_role_policy(
                    RoleName='InsuranceClaimApp-Role',
                    PolicyName=policy_name,
                    PolicyDocument=json.dumps(policy_doc)
                )
                logger.info(f"✓ Attached {policy_name} policy to application role")
            except Exception as e:
                logger.error(f"✗ Error attaching {policy_name} policy: {str(e)}")
        
        # Admin Role
        admin_policy = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": [
                        "dynamodb:*",
                        "s3:*",
                        "cloudwatch:*",
                        "logs:*"
                    ],
                    "Resource": "*"
                }
            ]
        }
        
        try:
            self.iam.create_role(
                RoleName='InsuranceClaimApp-AdminRole',
                AssumeRolePolicyDocument=json.dumps({
                    "Version": "2012-10-17",
                    "Statement": [{
                        "Effect": "Allow",
                        "Principal": {"AWS": f"arn:aws:iam::{self.account_id}:root"},
                        "Action": "sts:AssumeRole"
                    }]
                }),
                Description='Admin role for Insurance Claim Management System'
            )
            self.iam.put_role_policy(
                RoleName='InsuranceClaimApp-AdminRole',
                PolicyName='AdminFullAccess',
                PolicyDocument=json.dumps(admin_policy)
            )
            logger.info("✓ Admin IAM role created")
        except ClientError as e:
            if e.response['Error']['Code'] == 'EntityAlreadyExists':
                logger.info("✓ Admin IAM role already exists")
            else:
                logger.error(f"✗ Error creating admin role: {str(e)}")
        
        # Customer Role (read-only access to their own claims)
        customer_policy = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": [
                        "dynamodb:GetItem",
                        "dynamodb:Query"
                    ],
                    "Resource": f"arn:aws:dynamodb:{self.region}:*:table/insurance-claims*",
                    "Condition": {
                        "ForAllValues:StringEquals": {
                            "dynamodb:LeadingKeys": ["${aws:username}"]
                        }
                    }
                },
                {
                    "Effect": "Allow",
                    "Action": ["s3:GetObject"],
                    "Resource": f"arn:aws:s3:::claim-insurance-buck-et/claims/*"
                }
            ]
        }
        
        try:
            self.iam.create_role(
                RoleName='InsuranceClaimApp-CustomerRole',
                AssumeRolePolicyDocument=json.dumps({
                    "Version": "2012-10-17",
                    "Statement": [{
                        "Effect": "Allow",
                        "Principal": {"AWS": f"arn:aws:iam::{self.account_id}:root"},
                        "Action": "sts:AssumeRole"
                    }]
                }),
                Description='Customer role for Insurance Claim Management System'
            )
            self.iam.put_role_policy(
                RoleName='InsuranceClaimApp-CustomerRole',
                PolicyName='CustomerReadOnly',
                PolicyDocument=json.dumps(customer_policy)
            )
            logger.info("✓ Customer IAM role created")
        except ClientError as e:
            if e.response['Error']['Code'] == 'EntityAlreadyExists':
                logger.info("✓ Customer IAM role already exists")
            else:
                logger.error(f"✗ Error creating customer role: {str(e)}")
        
        return roles_created
    
    def create_cloudwatch_alarms(self):
        """Create CloudWatch alarms for monitoring"""
        alarms = [
            {
                'AlarmName': 'HighClaimSubmissionRate',
                'MetricName': 'NumberOfClaims',
                'Namespace': 'InsuranceClaimApp',
                'Statistic': 'Sum',
                'Period': 300,
                'EvaluationPeriods': 1,
                'Threshold': 100.0,
                'ComparisonOperator': 'GreaterThanThreshold'
            },
            {
                'AlarmName': 'HighErrorRate',
                'MetricName': 'ErrorCount',
                'Namespace': 'InsuranceClaimApp',
                'Statistic': 'Sum',
                'Period': 300,
                'EvaluationPeriods': 1,
                'Threshold': 10.0,
                'ComparisonOperator': 'GreaterThanThreshold'
            }
        ]
        
        for alarm_config in alarms:
            try:
                self.cloudwatch.put_metric_alarm(
                    AlarmName=alarm_config['AlarmName'],
                    MetricName=alarm_config['MetricName'],
                    Namespace=alarm_config['Namespace'],
                    Statistic=alarm_config['Statistic'],
                    Period=alarm_config['Period'],
                    EvaluationPeriods=alarm_config['EvaluationPeriods'],
                    Threshold=alarm_config['Threshold'],
                    ComparisonOperator=alarm_config['ComparisonOperator'],
                    AlarmActions=[]  # Can add SNS topic ARN here
                )
                logger.info(f"✓ CloudWatch alarm '{alarm_config['AlarmName']}' created")
            except Exception as e:
                logger.error(f"✗ Error creating CloudWatch alarm: {str(e)}")
    
    def create_elastic_beanstalk_application(self, app_name='insurance-claim-app'):
        """Create Elastic Beanstalk application"""
        try:
            self.elasticbeanstalk.create_application(
                ApplicationName=app_name,
                Description='Insurance Claim Management System',
                ResourceLifecycleConfig={
                    'ServiceRole': f'arn:aws:iam::{self.account_id}:role/aws-elasticbeanstalk-service-role'
                }
            )
            logger.info(f"✓ Elastic Beanstalk application '{app_name}' created")
        except ClientError as e:
            if 'already exists' in str(e).lower():
                logger.info(f"✓ Elastic Beanstalk application '{app_name}' already exists")
            else:
                logger.error(f"✗ Error creating Elastic Beanstalk application: {str(e)}")
    
    def setup_all(self, rds_password=None):
        """Run complete AWS setup"""
        logger.info("="*80)
        logger.info("Starting Complete AWS Infrastructure Setup")
        logger.info("="*80)
        
        try:
            # Core services
            logger.info("\n[1/7] Setting up DynamoDB...")
            self.create_dynamodb_table()
            
            logger.info("\n[2/7] Setting up S3...")
            self.create_s3_bucket()
            
            logger.info("\n[3/7] Setting up IAM roles...")
            self.create_iam_roles()
            
            logger.info("\n[4/7] Setting up CloudWatch monitoring...")
            self.create_cloudwatch_alarms()
            
            logger.info("\n[5/7] Setting up Elastic Beanstalk...")
            self.create_elastic_beanstalk_application()
            
            logger.info("\n[6/7] Optional: Setting up RDS...")
            if rds_password:
                self.create_rds_instance(master_password=rds_password)
            else:
                logger.info("⚠ Skipping RDS (using DynamoDB as primary database)")
            
            logger.info("\n[7/7] Setup Summary...")
            logger.info("="*80)
            logger.info("✅ AWS Infrastructure Setup Complete!")
            logger.info("="*80)
            logger.info("\n📋 Next Steps:")
            logger.info("1. Configure Elastic Beanstalk environment (see .ebextensions/)")
            logger.info("2. Set up CodePipeline (run setup_codepipeline.py)")
            logger.info("3. Deploy application to Elastic Beanstalk")
            logger.info("4. Configure SSL certificate for HTTPS")
            logger.info("\n💡 Note: RDS is optional. DynamoDB is the primary database.")
            
        except Exception as e:
            logger.error(f"❌ Setup failed: {str(e)}")
            raise


if __name__ == '__main__':
    import sys
    
    # Get RDS password from command line or environment
    rds_password = os.getenv('RDS_PASSWORD') or (sys.argv[1] if len(sys.argv) > 1 else None)
    
    region = os.getenv('AWS_REGION', 'eu-north-1')
    setup = CompleteAWSSetup(region=region)
    setup.setup_all(rds_password=rds_password)

