"""
Insurance Claim Processor Library
Custom library for claim validation, scoring, and processing
Developed for Cloud-Based Insurance Claim Management System
"""

from datetime import datetime, timedelta
import re
from typing import Dict, List, Tuple, Optional


class ClaimValidator:
    """Validates insurance claim data against business rules"""
    
    MIN_CLAIM_AMOUNT = 100
    MAX_CLAIM_AMOUNT = 500000
    MAX_DESCRIPTION_LENGTH = 1000
    
    @staticmethod
    def validate_email(email: str) -> Tuple[bool, str]:
        """Validate email format"""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if re.match(pattern, email):
            return True, "Email is valid"
        return False, "Invalid email format"
    
    @staticmethod
    def validate_phone(phone: str) -> Tuple[bool, str]:
        """Validate phone number format"""
        phone_clean = re.sub(r'\D', '', phone)
        if len(phone_clean) >= 10:
            return True, "Phone number is valid"
        return False, "Phone number must have at least 10 digits"
    
    @staticmethod
    def validate_claim_amount(amount: float) -> Tuple[bool, str]:
        """Validate claim amount is within acceptable range"""
        if amount < ClaimValidator.MIN_CLAIM_AMOUNT:
            return False, f"Claim amount must be at least ${ClaimValidator.MIN_CLAIM_AMOUNT}"
        if amount > ClaimValidator.MAX_CLAIM_AMOUNT:
            return False, f"Claim amount cannot exceed ${ClaimValidator.MAX_CLAIM_AMOUNT}"
        return True, "Claim amount is valid"
    
    @staticmethod
    def validate_description(description: str) -> Tuple[bool, str]:
        """Validate claim description"""
        if not description or len(description.strip()) == 0:
            return False, "Description cannot be empty"
        if len(description) > ClaimValidator.MAX_DESCRIPTION_LENGTH:
            return False, f"Description cannot exceed {ClaimValidator.MAX_DESCRIPTION_LENGTH} characters"
        return True, "Description is valid"
    
    @staticmethod
    def validate_incident_date(incident_date: str) -> Tuple[bool, str]:
        """Validate incident date is not in future and not too old"""
        try:
            incident = datetime.strptime(incident_date, '%Y-%m-%d')
            today = datetime.now()
            max_age = today - timedelta(days=365)
            
            if incident > today:
                return False, "Incident date cannot be in the future"
            if incident < max_age:
                return False, "Incident date cannot be older than 1 year"
            return True, "Incident date is valid"
        except ValueError:
            return False, "Invalid date format. Use YYYY-MM-DD"
    
    @staticmethod
    def validate_policy_number(policy_number: str) -> Tuple[bool, str]:
        """Validate policy number format"""
        if not policy_number or len(policy_number.strip()) == 0:
            return False, "Policy number cannot be empty"
        if not re.match(r'^[A-Z0-9]{6,}$', policy_number):
            return False, "Policy number must be alphanumeric with at least 6 characters"
        return True, "Policy number is valid"


class ClaimScorer:
    """Scores claims for fraud risk and priority"""
    
    BASE_SCORE = 50  # Base score out of 100
    
    @staticmethod
    def calculate_fraud_risk_score(claim_data: Dict) -> Dict:
        """
        Calculate fraud risk score for a claim
        Higher score = higher fraud risk
        """
        score = ClaimScorer.BASE_SCORE
        risk_factors = []
        
        # Factor 1: Unusual claim amount (very high or very low)
        amount = float(claim_data.get('amount', 0))
        if amount > 100000:
            score += 15
            risk_factors.append("High claim amount")
        elif amount < 500:
            score += 5
            risk_factors.append("Low claim amount")
        
        # Factor 2: Description length (too short might be suspicious)
        description = str(claim_data.get('description', ''))
        if len(description) < 50:
            score += 10
            risk_factors.append("Minimal description provided")
        
        # Factor 3: Multiple claims in short timeframe (simulated)
        claim_count = int(claim_data.get('previous_claims', 0))
        if claim_count > 3:
            score += 20
            risk_factors.append("Multiple recent claims")
        
        # Factor 4: Vague claim type
        claim_type = str(claim_data.get('claim_type', '')).lower()
        vague_types = ['other', 'miscellaneous', 'general']
        if claim_type in vague_types:
            score += 8
            risk_factors.append("Vague claim type")
        
        # Normalize score to 0-100
        score = min(100, max(0, score))
        
        risk_level = "High" if score >= 70 else "Medium" if score >= 40 else "Low"
        
        return {
            'fraud_risk_score': score,
            'risk_level': risk_level,
            'risk_factors': risk_factors,
            'recommendation': 'Requires manual review' if risk_level == 'High' else 'Auto-processing available'
        }
    
    @staticmethod
    def calculate_priority_score(claim_data: Dict) -> Dict:
        """
        Calculate priority score for claim processing
        Higher score = higher priority
        """
        priority_score = 50
        
        # Priority factors
        if claim_data.get('claim_type') == 'Health':
            priority_score += 20
        
        if float(claim_data.get('amount', 0)) > 50000:
            priority_score += 15
        
        if claim_data.get('submitted_with_documents', False):
            priority_score += 10
        
        priority_score = min(100, max(0, priority_score))
        priority_level = "High" if priority_score >= 70 else "Medium" if priority_score >= 40 else "Low"
        
        return {
            'priority_score': priority_score,
            'priority_level': priority_level
        }


class ClaimProcessor:
    """Main claim processing orchestrator"""
    
    @staticmethod
    def validate_and_score_claim(claim_data: Dict) -> Dict:
        """
        Complete validation and scoring pipeline for a claim
        Returns comprehensive analysis
        """
        validation_results = {
            'is_valid': True,
            'errors': [],
            'warnings': []
        }
        
        # Validate required fields
        required_fields = ['customer_name', 'email', 'policy_number', 'claim_type', 
                         'amount', 'incident_date', 'description']
        
        for field in required_fields:
            if field not in claim_data or not claim_data[field]:
                validation_results['errors'].append(f"{field.replace('_', ' ')} is required")
                validation_results['is_valid'] = False
        
        if not validation_results['is_valid']:
            return validation_results
        
        # Validate individual fields
        email_valid, email_msg = ClaimValidator.validate_email(claim_data['email'])
        if not email_valid:
            validation_results['errors'].append(email_msg)
            validation_results['is_valid'] = False
        
        phone = claim_data.get('phone', '')
        if phone:
            phone_valid, phone_msg = ClaimValidator.validate_phone(phone)
            if not phone_valid:
                validation_results['warnings'].append(phone_msg)
        
        amount_valid, amount_msg = ClaimValidator.validate_claim_amount(float(claim_data['amount']))
        if not amount_valid:
            validation_results['errors'].append(amount_msg)
            validation_results['is_valid'] = False
        
        desc_valid, desc_msg = ClaimValidator.validate_description(claim_data['description'])
        if not desc_valid:
            validation_results['errors'].append(desc_msg)
            validation_results['is_valid'] = False
        
        date_valid, date_msg = ClaimValidator.validate_incident_date(claim_data['incident_date'])
        if not date_valid:
            validation_results['errors'].append(date_msg)
            validation_results['is_valid'] = False
        
        policy_valid, policy_msg = ClaimValidator.validate_policy_number(claim_data['policy_number'])
        if not policy_valid:
            validation_results['errors'].append(policy_msg)
            validation_results['is_valid'] = False
        
        # If all validations passed, perform scoring
        if validation_results['is_valid']:
            fraud_analysis = ClaimScorer.calculate_fraud_risk_score(claim_data)
            priority_analysis = ClaimScorer.calculate_priority_score(claim_data)
            
            validation_results.update({
                'fraud_analysis': fraud_analysis,
                'priority_analysis': priority_analysis,
                'processing_status': 'Ready for processing',
                'recommended_action': fraud_analysis.get('recommendation')
            })
        
        return validation_results
    
    @staticmethod
    def generate_claim_summary(claim_data: Dict) -> str:
        """Generate human-readable claim summary"""
        summary = f"""
CLAIM SUMMARY
=============
Policy Number: {claim_data.get('policy_number', 'N/A')}
Customer: {claim_data.get('customer_name', 'N/A')}
Claim Type: {claim_data.get('claim_type', 'N/A')}
Amount: ${float(claim_data.get('amount', 0)):,.2f}
Incident Date: {claim_data.get('incident_date', 'N/A')}
Status: {claim_data.get('status', 'Pending')}

Description:
{claim_data.get('description', 'N/A')}
"""
        return summary
