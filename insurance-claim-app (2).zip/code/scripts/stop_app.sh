#!/bin/bash
set -e

echo "=== Stopping Application ==="

# Stop Flask and Next.js processes
pkill -f gunicorn || true
pkill -f "node.*next" || true
pkill -f "pnpm.*start" || true

echo "Application stopped successfully"
