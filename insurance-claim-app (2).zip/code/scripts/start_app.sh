#!/bin/bash
set -e

echo "=== Starting Application ==="

# Source environment variables
export AWS_REGION=${AWS_REGION:-eu-north-1}
export DYNAMODB_TABLE_NAME=${DYNAMODB_TABLE_NAME:-insurance-claims}
export S3_BUCKET_NAME=${S3_BUCKET_NAME:-claim-insurance-buck-et}
export FLASK_ENV=production

# Start Flask application using Gunicorn
pip3 install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app &

# Build and serve Next.js frontend
npm install -g pnpm
pnpm install --frozen-lockfile
pnpm build
pnpm start &

echo "Application started successfully"
