"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Spinner } from "@/components/ui/spinner"
import { AlertCircle, CheckCircle, Clock, TrendingUp, FileUp } from "lucide-react"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000"

export default function Home() {
  const [activeTab, setActiveTab] = useState("submit")
  const [claims, setClaims] = useState([])
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    customer_name: "",
    email: "",
    phone: "",
    policy_number: "",
    claim_type: "Medical",
    amount: "",
    incident_date: "",
    description: "",
  })
  const [submitMessage, setSubmitMessage] = useState("")
  const [submitError, setSubmitError] = useState("")

  useEffect(() => {
    fetchClaims()
    fetchStats()
  }, [])

  const fetchClaims = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/claims`)
      if (response.ok) {
        const data = await response.json()
        setClaims(data.claims || [])
      }
    } catch (error) {
      console.error("Error fetching claims:", error)
    }
  }

  const fetchStats = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/stats`)
      if (response.ok) {
        const data = await response.json()
        setStats(data.stats)
      }
    } catch (error) {
      console.error("Error fetching stats:", error)
    }
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmitClaim = async (e) => {
    e.preventDefault()
    setLoading(true)
    setSubmitMessage("")
    setSubmitError("")

    try {
      const response = await fetch(`${API_BASE_URL}/api/claims`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (response.ok) {
        setSubmitMessage(`Claim submitted successfully! Claim ID: ${data.claim_id}`)
        setFormData({
          customer_name: "",
          email: "",
          phone: "",
          policy_number: "",
          claim_type: "Medical",
          amount: "",
          incident_date: "",
          description: "",
        })
        setTimeout(() => {
          setActiveTab("view")
          fetchClaims()
          fetchStats()
        }, 2000)
      } else {
        setSubmitError(data.errors?.join(", ") || "Error submitting claim")
      }
    } catch (error) {
      setSubmitError("Error submitting claim: " + error.message)
    } finally {
      setLoading(false)
    }
  }

  const getRiskBadgeVariant = (level) => {
    switch (level) {
      case "High":
        return "destructive"
      case "Medium":
        return "secondary"
      default:
        return "outline"
    }
  }

  const getPriorityBadgeVariant = (level) => {
    switch (level) {
      case "High":
        return "default"
      case "Medium":
        return "secondary"
      default:
        return "outline"
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case "Approved":
        return "text-green-600"
      case "Rejected":
        return "text-red-600"
      case "Settled":
        return "text-blue-600"
      default:
        return "text-amber-600"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Claim Manager</h1>
                <p className="text-sm text-slate-400">Insurance Claims Management System</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Grid */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-300">Total Claims</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-white">{stats.total_claims}</div>
                <p className="text-xs text-slate-400 mt-1">All time submissions</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-300">Pending</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-amber-400">{stats.pending}</div>
                <p className="text-xs text-slate-400 mt-1">Awaiting review</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-300">High Risk</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-red-400">{stats.high_risk_count}</div>
                <p className="text-xs text-slate-400 mt-1">Fraud risk detected</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-slate-300">Total Amount</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-400">${stats.total_amount.toLocaleString()}</div>
                <p className="text-xs text-slate-400 mt-1">Claimed value</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-slate-800/50 border border-slate-700">
            <TabsTrigger value="submit" className="text-sm">
              Submit Claim
            </TabsTrigger>
            <TabsTrigger value="view" className="text-sm">
              View Claims
            </TabsTrigger>
          </TabsList>

          {/* Submit Claim Tab */}
          <TabsContent value="submit" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Submit New Claim</CardTitle>
                <CardDescription className="text-slate-400">
                  Fill in the details to submit an insurance claim
                </CardDescription>
              </CardHeader>
              <CardContent>
                {submitMessage && (
                  <Alert className="mb-6 bg-green-900/20 border-green-700">
                    <CheckCircle className="h-4 w-4 text-green-400" />
                    <AlertDescription className="text-green-300">{submitMessage}</AlertDescription>
                  </Alert>
                )}
                {submitError && (
                  <Alert className="mb-6 bg-red-900/20 border-red-700">
                    <AlertCircle className="h-4 w-4 text-red-400" />
                    <AlertDescription className="text-red-300">{submitError}</AlertDescription>
                  </Alert>
                )}

                <form onSubmit={handleSubmitClaim} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="customer_name" className="text-slate-300">
                        Full Name
                      </Label>
                      <Input
                        id="customer_name"
                        name="customer_name"
                        value={formData.customer_name}
                        onChange={handleInputChange}
                        placeholder="John Doe"
                        className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-slate-300">
                        Email Address
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="john@example.com"
                        className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone" className="text-slate-300">
                        Phone Number
                      </Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="+1 (555) 000-0000"
                        className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="policy_number" className="text-slate-300">
                        Policy Number
                      </Label>
                      <Input
                        id="policy_number"
                        name="policy_number"
                        value={formData.policy_number}
                        onChange={handleInputChange}
                        placeholder="POL123456"
                        className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="claim_type" className="text-slate-300">
                        Claim Type
                      </Label>
                      <select
                        id="claim_type"
                        name="claim_type"
                        value={formData.claim_type}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 text-white rounded-md text-sm"
                      >
                        <option value="Medical">Medical</option>
                        <option value="Auto">Auto</option>
                        <option value="Property">Property</option>
                        <option value="Health">Health</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="amount" className="text-slate-300">
                        Claim Amount ($)
                      </Label>
                      <Input
                        id="amount"
                        name="amount"
                        type="number"
                        value={formData.amount}
                        onChange={handleInputChange}
                        placeholder="5000"
                        className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="incident_date" className="text-slate-300">
                        Incident Date
                      </Label>
                      <Input
                        id="incident_date"
                        name="incident_date"
                        type="date"
                        value={formData.incident_date}
                        onChange={handleInputChange}
                        className="bg-slate-700/50 border-slate-600 text-white"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description" className="text-slate-300">
                      Description
                    </Label>
                    <textarea
                      id="description"
                      name="description"
                      value={formData.description}
                      onChange={handleInputChange}
                      placeholder="Provide detailed description of the claim..."
                      rows={4}
                      className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 text-white rounded-md text-sm placeholder:text-slate-400"
                      required
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold"
                  >
                    {loading ? (
                      <>
                        <Spinner className="mr-2 h-4 w-4" />
                        Submitting...
                      </>
                    ) : (
                      <>
                        <FileUp className="mr-2 h-4 w-4" />
                        Submit Claim
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* View Claims Tab */}
          <TabsContent value="view" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Claims List</CardTitle>
                <CardDescription className="text-slate-400">View and manage all submitted claims</CardDescription>
              </CardHeader>
              <CardContent>
                {claims.length === 0 ? (
                  <div className="text-center py-8">
                    <Clock className="mx-auto h-8 w-8 text-slate-500 mb-2" />
                    <p className="text-slate-400">No claims found</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-slate-700 hover:bg-slate-700/30">
                          <TableHead className="text-slate-300">Claim ID</TableHead>
                          <TableHead className="text-slate-300">Type</TableHead>
                          <TableHead className="text-slate-300">Amount</TableHead>
                          <TableHead className="text-slate-300">Status</TableHead>
                          <TableHead className="text-slate-300">Risk Level</TableHead>
                          <TableHead className="text-slate-300">Priority</TableHead>
                          <TableHead className="text-slate-300">Date</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {claims.map((claim) => (
                          <TableRow key={claim.claim_id} className="border-slate-700 hover:bg-slate-700/30">
                            <TableCell className="text-slate-300 font-mono text-sm">{claim.claim_id}</TableCell>
                            <TableCell className="text-slate-300">{claim.claim_type}</TableCell>
                            <TableCell className="text-slate-300 font-semibold">
                              ${claim.amount?.toLocaleString()}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className={`${getStatusColor(claim.status)} border-current`}>
                                {claim.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant={getRiskBadgeVariant(claim.fraud_risk_level)}>
                                {claim.fraud_risk_level}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant={getPriorityBadgeVariant(claim.priority_level)}>
                                {claim.priority_level}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-slate-400 text-sm">
                              {new Date(claim.created_at).toLocaleDateString()}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
