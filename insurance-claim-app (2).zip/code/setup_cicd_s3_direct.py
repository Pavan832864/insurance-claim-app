"""
AWS CodePipeline Setup for S3-based CI/CD (Direct to Elastic Beanstalk)
Creates a pipeline that deploys directly from S3 to Elastic Beanstalk
"""
import boto3
import json
import sys
import time

# AWS Clients
codepipeline = boto3.client('codepipeline', region_name='eu-north-1')
codebuild = boto3.client('codebuild', region_name='eu-north-1')
iam = boto3.client('iam')
s3_client = boto3.client('s3', region_name='eu-north-1')
eb = boto3.client('elasticbeanstalk', region_name='eu-north-1')

# Configuration
AWS_ACCOUNT_ID = boto3.client('sts').get_caller_identity()['Account']
AWS_REGION = 'eu-north-1'
PROJECT_NAME = 'InsuranceClaimApp'
APP_NAME = 'insurance-claim-app'
ENV_NAME = 'insurance-claim-app-single'
ARTIFACT_BUCKET = f'{APP_NAME}-pipeline-artifacts-{AWS_ACCOUNT_ID}'

print("="*80)
print("AWS CodePipeline Setup for S3-based CI/CD")
print("="*80)

# Step 1: Verify S3 bucket exists
print("\n[1/5] Verifying S3 artifact bucket...")
try:
    s3_client.head_bucket(Bucket=ARTIFACT_BUCKET)
    print(f"✓ S3 bucket exists: {ARTIFACT_BUCKET}")
except:
    print(f"✗ S3 bucket not found: {ARTIFACT_BUCKET}")
    print("  Creating bucket...")
    try:
        s3_client.create_bucket(
            Bucket=ARTIFACT_BUCKET,
            CreateBucketConfiguration={'LocationConstraint': AWS_REGION}
        )
        s3_client.put_bucket_versioning(
            Bucket=ARTIFACT_BUCKET,
            VersioningConfiguration={'Status': 'Enabled'}
        )
        print(f"✓ S3 bucket created: {ARTIFACT_BUCKET}")
    except Exception as e:
        print(f"✗ Error creating bucket: {str(e)}")
        sys.exit(1)

# Step 2: Create/Get CodePipeline Service Role
print("\n[2/5] Setting up CodePipeline service role...")
pipeline_role_name = 'CodePipelineServiceRole-InsuranceClaim'
pipeline_role_arn = f'arn:aws:iam::{AWS_ACCOUNT_ID}:role/{pipeline_role_name}'

try:
    iam.get_role(RoleName=pipeline_role_name)
    print(f"✓ CodePipeline service role exists: {pipeline_role_name}")
except iam.exceptions.NoSuchEntityException:
    print(f"Creating CodePipeline service role...")
    trust_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {"Service": "codepipeline.amazonaws.com"},
                "Action": "sts:AssumeRole"
            }
        ]
    }
    iam.create_role(
        RoleName=pipeline_role_name,
        AssumeRolePolicyDocument=json.dumps(trust_policy),
        Description='Service role for CodePipeline'
    )
    print(f"✓ CodePipeline service role created: {pipeline_role_name}")
    time.sleep(2)

# Attach policies to CodePipeline role
policies_to_attach = [
    'arn:aws:iam::aws:policy/AWSCodePipeline_FullAccess',
    'arn:aws:iam::aws:policy/AmazonS3FullAccess',
    'arn:aws:iam::aws:policy/AWSElasticBeanstalkFullAccess'
]

for policy_arn in policies_to_attach:
    try:
        iam.attach_role_policy(RoleName=pipeline_role_name, PolicyArn=policy_arn)
        print(f"✓ Attached policy: {policy_arn.split('/')[-1]}")
    except Exception as e:
        print(f"  Note: Policy attachment issue (may already be attached): {str(e)}")

# Step 3: Create CodeBuild project (minimal pass-through)
print("\n[3/5] Creating CodeBuild project (pass-through)...")
build_project_name = 'InsuranceClaimAppBuild'

# Simple buildspec that just passes source to output
buildspec_content = """version: 0.2
phases:
  build:
    commands:
      - echo "Pass-through build - copying source to output"
      - cp -r $CODEBUILD_SRC_DIR/* $CODEBUILD_SRC_DIR_output/
artifacts:
  files:
    - '**/*'
"""

try:
    codebuild.create_project(
        name=build_project_name,
        description='Pass-through build for Insurance Claim App',
        source={
            'type': 'CODEPIPELINE',
            'buildspec': buildspec_content
        },
        artifacts={
            'type': 'CODEPIPELINE',
            'name': 'BuildOutput'
        },
        environment={
            'type': 'LINUX_CONTAINER',
            'image': 'aws/codebuild/standard:7.0',
            'computeType': 'BUILD_GENERAL1_SMALL',
            'privilegedMode': False
        },
        serviceRole=f'arn:aws:iam::{AWS_ACCOUNT_ID}:role/{build_project_name}-Role'
    )
    print(f"✓ CodeBuild project created: {build_project_name}")
except codebuild.exceptions.ResourceAlreadyExistsException:
    print(f"✓ CodeBuild project already exists: {build_project_name}")
    # Update it
    try:
        codebuild.update_project(
            name=build_project_name,
            description='Pass-through build for Insurance Claim App',
            source={
                'type': 'CODEPIPELINE',
                'buildspec': buildspec_content
            },
            artifacts={
                'type': 'CODEPIPELINE',
                'name': 'BuildOutput'
            },
            environment={
                'type': 'LINUX_CONTAINER',
                'image': 'aws/codebuild/standard:7.0',
                'computeType': 'BUILD_GENERAL1_SMALL',
                'privilegedMode': False
            },
            serviceRole=f'arn:aws:iam::{AWS_ACCOUNT_ID}:role/{build_project_name}-Role'
        )
        print(f"✓ CodeBuild project updated")
    except Exception as e:
        print(f"  Note: Could not update CodeBuild project: {str(e)}")
except Exception as e:
    print(f"  Note: CodeBuild project creation issue (may have limits): {str(e)}")
    print(f"  Pipeline will work but Build stage may fail - you can skip it manually")

# Step 4: Create CodePipeline
print("\n[4/5] Creating CodePipeline...")

pipeline_config = {
    'name': 'InsuranceClaimAppPipeline',
    'roleArn': pipeline_role_arn,
    'artifactStore': {
        'type': 'S3',
        'location': ARTIFACT_BUCKET
    },
    'stages': [
        {
            'name': 'Source',
            'actions': [
                {
                    'name': 'SourceAction',
                    'actionTypeId': {
                        'category': 'Source',
                        'owner': 'AWS',
                        'provider': 'S3',
                        'version': '1'
                    },
                    'configuration': {
                        'S3Bucket': ARTIFACT_BUCKET,
                        'S3ObjectKey': 'source.zip',
                        'PollForSourceChanges': 'false'
                    },
                    'outputArtifacts': [{'name': 'SourceOutput'}]
                }
            ]
        },
        {
            'name': 'Build',
            'actions': [
                {
                    'name': 'BuildAction',
                    'actionTypeId': {
                        'category': 'Build',
                        'owner': 'AWS',
                        'provider': 'CodeBuild',
                        'version': '1'
                    },
                    'configuration': {
                        'ProjectName': build_project_name
                    },
                    'inputArtifacts': [{'name': 'SourceOutput'}],
                    'outputArtifacts': [{'name': 'BuildOutput'}]
                }
            ]
        },
        {
            'name': 'Deploy',
            'actions': [
                {
                    'name': 'DeployAction',
                    'actionTypeId': {
                        'category': 'Deploy',
                        'owner': 'AWS',
                        'provider': 'ElasticBeanstalk',
                        'version': '1'
                    },
                    'configuration': {
                        'ApplicationName': APP_NAME,
                        'EnvironmentName': ENV_NAME
                    },
                    'inputArtifacts': [{'name': 'BuildOutput'}]
                }
            ]
        }
    ]
}

try:
    codepipeline.create_pipeline(pipeline=pipeline_config)
    print("✓ CodePipeline created: InsuranceClaimAppPipeline")
except codepipeline.exceptions.PipelineNameInUseException:
    print("✓ CodePipeline already exists - updating...")
    codepipeline.update_pipeline(pipeline=pipeline_config)
    print("✓ CodePipeline updated")
except Exception as e:
    print(f"✗ Error creating CodePipeline: {str(e)}")
    print(f"  Details: {str(e)}")
    sys.exit(1)

# Step 5: Create deployment script
print("\n[5/5] Creating deployment script...")
deploy_script = """#!/bin/bash
# Quick Deploy Script for S3-based CI/CD
# Usage: ./deploy.sh

set -e

echo "=========================================="
echo "Deploying to Elastic Beanstalk via CI/CD"
echo "=========================================="
echo ""



echo "Step 1: Creating deployment package..."
zip -r source.zip app.py static/ .ebextensions/ requirements.txt claim_processor_library.py \\
  -x "*.pyc" "__pycache__/*" "*.git/*" ".elasticbeanstalk/*" \\
  > /dev/null 2>&1

if [ ! -f "source.zip" ]; then
    echo "❌ Error: Failed to create source.zip"
    exit 1
fi

SIZE=$(ls -lh source.zip | awk '{{print $5}}')
echo "✓ Package created: source.zip ($SIZE)"
echo ""

echo "Step 2: Uploading to S3..."
aws s3 cp source.zip s3://{ARTIFACT_BUCKET}/source.zip --region {AWS_REGION}

if [ $? -ne 0 ]; then
    echo "❌ Error: Failed to upload to S3"
    exit 1
fi

echo "✓ Uploaded to S3"
echo ""

echo "Step 3: Triggering pipeline..."
EXECUTION_ID=$(aws codepipeline start-pipeline-execution \\
  --name InsuranceClaimAppPipeline \\
  --region {AWS_REGION} \\
  --query 'pipelineExecutionId' \\
  --output text)

if [ $? -ne 0 ]; then
    echo "❌ Error: Failed to trigger pipeline"
    exit 1
fi

echo "✓ Pipeline triggered"
echo ""
echo "=========================================="
echo "Deployment Started!"
echo "=========================================="
echo ""
echo "Pipeline Execution ID: $EXECUTION_ID"
echo ""
echo "View pipeline status:"
echo "https://console.aws.amazon.com/codesuite/codepipeline/pipelines/InsuranceClaimAppPipeline/view"
echo ""
echo "Monitor progress:"
echo "  aws codepipeline get-pipeline-state --name InsuranceClaimAppPipeline --region {AWS_REGION}"
echo ""
echo "Check Elastic Beanstalk:"
echo "  eb status"
echo ""

rm -f source.zip
echo "✓ Cleaned up local source.zip"
""".format(ARTIFACT_BUCKET=ARTIFACT_BUCKET, AWS_REGION=AWS_REGION)

with open('deploy.sh', 'w') as f:
    f.write(deploy_script)

import os
os.chmod('deploy.sh', 0o755)
print("✓ Created deploy.sh script")

print("\n" + "="*80)
print("✅ CodePipeline Setup Complete!")
print("="*80)
print(f"\nPipeline Name: InsuranceClaimAppPipeline")
print(f"S3 Source Bucket: {ARTIFACT_BUCKET}")
print(f"S3 Source Key: source.zip")
print(f"Target Environment: {ENV_NAME}")
print("\nTo deploy:")
print("  1. Run: ./deploy.sh")
print("  2. Or manually:")
print(f"     aws s3 cp source.zip s3://{ARTIFACT_BUCKET}/source.zip")
print("     aws codepipeline start-pipeline-execution --name InsuranceClaimAppPipeline")
print("\nView pipeline:")
print("  https://console.aws.amazon.com/codesuite/codepipeline/pipelines/InsuranceClaimAppPipeline/view")
print("")

